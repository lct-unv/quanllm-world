# 从竞赛题面提取示例 I/O 测试对。
# 覆盖已勘察格式：
#   A) 围栏版：``` 包裹的 Input/Output（含 ### Input / ### Output 标题）
#   B) 纯文本版：Example(s) 区段内成对的 Input/Output 行首标题（行级状态机解析）
#   C) "Sample Input"/"SAMPLE INPUT" 配对（同属行级状态机）
# 返回 [(stdin, expected_stdout), ...]，提取不到返回空列表。
import re

_ws_norm = re.compile(r"\s+")


def qkey(text: str) -> str:
    import hashlib
    return hashlib.sha1(_ws_norm.sub(" ", text.strip().lower()).encode("utf-8")).hexdigest()

FENCED_PAIR = re.compile(
    r"#*\s*(?:Sample\s+)?Input[^\n]*\n+```[^\n]*\n(.*?)```\s*\n+#*\s*(?:Sample\s+)?Output[^\n]*\n+```[^\n]*\n(.*?)```",
    re.S | re.I,
)

EXAMPLE_MARK = re.compile(
    r"^\s*(?:[-=#*]{2,}\s*)?(?:#+\s*)?(?:Example(?:s)?|Examples?)\s*(?:[-=*]{2,})?\s*$",
    re.I | re.M,
)

_HDR = re.compile(r"^\s*(?:[-=#*]{2,}\s*)?(?:#+\s*)?(input|output|note|explanation|constraints?|subtasks?|scoring|hint|output\s+details?|input\s+details?|output\s+format|input\s+format|output\s+specification)s?\s*:?\s*(?:[-=*]{2,})?\s*$", re.I)


def _looks_prose(block: str) -> bool:
    """输入块若像英文散文（长句、句号结尾、无数字），判定为误捕获的说明段。"""
    first = next((l.strip() for l in block.split("\n") if l.strip()), "")
    if not first:
        return False
    words = first.split()
    return len(words) >= 4 and first.endswith((".", ":")) and not any(c.isdigit() for c in first)


def _parse_blocks(section: str):
    """行级状态机：input 标题收集到 output 标题，output 标题收集到下一个 input 标题或终止标题。"""
    tests = []
    state = None  # None | 'in' | 'out'
    buf_in, buf_out = [], []

    def flush():
        nonlocal buf_in, buf_out
        if buf_out:
            tests.append(("\n".join(buf_in).strip("\n"), "\n".join(buf_out).strip("\n")))
        buf_in, buf_out = [], []

    for line in section.split("\n"):
        m = _HDR.match(line)
        tag = m.group(1).lower() if m else None
        if tag == "input":
            if state == "out":
                flush()
            state = "in"
            buf_in = []
            continue
        if tag == "output":
            if state == "in":
                state = "out"
                buf_out = []
                continue
            state = None
            continue
        if tag is not None:  # note/constraints 等终止当前块
            if state == "out":
                flush()
            state = None
            continue
        if state == "in":
            buf_in.append(line)
        elif state == "out":
            buf_out.append(line)
    if state == "out":
        flush()
    return [(i, o) for i, o in tests if o.strip()]


def extract_tests(problem: str):
    # A) 围栏对优先（最可靠）
    tests = [
        (m.group(1).strip("\n"), m.group(2).strip("\n"))
        for m in FENCED_PAIR.finditer(problem)
    ]
    if tests:
        return [(i, o) for i, o in tests if o.strip()]

    # B/C) 锚定 Example/Sample 标记后的区段
    marks = list(EXAMPLE_MARK.finditer(problem))
    if not marks:
        # 无 Example 标题但直接有 Sample Input 块：锚定到首个 Sample Input，避免吞掉题面说明段
        m = re.search(r"^\s*sample\s+input\s*:?\s*$", problem, re.I | re.M)
        if m:
            return [(i, o) for i, o in _parse_blocks(problem[m.start():]) if not _looks_prose(i)]
        return []
    return [(i, o) for i, o in _parse_blocks(problem[marks[0].start():]) if not _looks_prose(i)]


def main():
    import json
    from collections import Counter
    c = Counter()
    per_n = Counter()
    with open(r"E:\quanllm-coder\datasets\sft_mix_50k\train_16h.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            q = d["messages"][0]["content"]
            tests = extract_tests(q)
            per_n[min(len(tests), 5)] += 1
            c["with_tests" if tests else "no_tests"] += 1
    print("coverage:", dict(c), "of 21000")
    print("tests-per-sample dist (capped at 5):", dict(sorted(per_n.items())))


if __name__ == "__main__":
    main()
