"""Generate, score, execute and compare sampled LiveCodeBench candidates."""
import argparse
import json
import math
import random
import statistics
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BENCH = ROOT.parent / "quanllm-coder" / "eval"
OUT = ROOT / "outputs" / "rollout_eval"
N, K, SEED = 128, 8, 71
MODELS = {
    "coder7b": ROOT / "models/Qwen2.5-Coder-7B-Instruct",
    "base14b": ROOT.parent / "quanllm-coder/models/Qwen3-14B",
    "surrogate": ROOT / "outputs/QuanLLM-World-Surrogate-14B",
}
GENERATORS = ("coder7b", "base14b")


def write(name, data):
    path = OUT / f"{name}.json"
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(data, indent=2), encoding="utf-8")
    temp.replace(path)


def read(name):
    return json.loads((OUT / f"{name}.json").read_text(encoding="utf-8"))


def problems():
    rows = [json.loads(line) for line in (BENCH / "lcb_v6_full.jsonl").read_text(
        encoding="utf-8").splitlines()]
    eligible = [row for row in rows if not row["starter_code"]]
    return random.Random(SEED).sample(eligible, N)


def inference(stage, model):
    from transformers import AutoTokenizer
    from vllm import LLM, SamplingParams

    sys.path.insert(0, str(BENCH))
    from gen_lcb import SYSTEM_MESSAGE_GENERIC, build_user, extract_code

    tokenizer = AutoTokenizer.from_pretrained(str(MODELS[model]))

    def chat(prompt, system=None):
        messages = [{"role": "system", "content": system}] if system else []
        messages.append({"role": "user", "content": prompt})
        return tokenizer.apply_chat_template(messages, tokenize=False,
                                             add_generation_prompt=True,
                                             enable_thinking=False)

    kwargs = dict(model=str(MODELS[model]), quantization="fp8",
                  max_model_len=8192, gpu_memory_utilization=.85)
    if stage == "score":
        kwargs.update(enforce_eager=True, max_num_seqs=32, max_num_batched_tokens=4096)
    llm = LLM(**kwargs)
    rows = problems()
    if stage == "generate":
        prompts = [chat(build_user(q), SYSTEM_MESSAGE_GENERIC) for q in rows]
        params = SamplingParams(n=K, temperature=.7, top_p=.95,
                                max_tokens=2048, seed=SEED, logprobs=1)
        results = llm.generate(prompts, params)
        candidates = {}
        for q, result in zip(rows, results, strict=True):
            candidates[q["question_id"]] = [
                {"code": extract_code(item.text), "mean_logprob": (
                    item.cumulative_logprob / max(1, len(item.token_ids)))}
                for item in result.outputs
            ]
        write(f"generated_{model}", candidates)
        return

    tokens = [tokenizer.encode(value, add_special_tokens=False) for value in ("A", "B")]
    assert all(len(ids) == 1 for ids in tokens)
    pass_token, fail_token = [ids[0] for ids in tokens]
    params = SamplingParams(temperature=0, max_tokens=1, prompt_logprobs=0)
    for generator in GENERATORS:
        candidates = read(f"generated_{generator}")
        prompts = []
        for q in rows:
            cases = json.loads(q["public_test_cases"])
            tests = "\n".join(f"Input: {c['input']!r}; expected: {c['output']!r}"
                              for c in cases)
            for item in candidates[q["question_id"]]:
                prompt = ("Predict whether this Python program correctly solves the full "
                          "problem. Answer A for pass or B for fail.\n\n"
                          f"{q['question_content']}\n\nPublic examples:\n{tests}\n\n"
                          f"Python candidate:\n{item['code']}")
                ids = tokenizer.encode(chat(prompt), add_special_tokens=False)
                if len(ids) > 8190:
                    ids = ids[:2048] + ids[-6142:]
                prompts.extend({"prompt_token_ids": ids + [token]}
                               for token in (pass_token, fail_token))
        started = time.perf_counter()
        results = llm.generate(prompts, params, use_tqdm=False)
        elapsed = time.perf_counter() - started
        scores = [pos.prompt_logprobs[-1][pass_token].logprob
                  - neg.prompt_logprobs[-1][fail_token].logprob
                  for pos, neg in zip(results[::2], results[1::2], strict=True)]
        write(f"scores_{model}_{generator}", {
            "seconds": elapsed, "problems": {
                q["question_id"]: scores[i*K:(i+1)*K] for i, q in enumerate(rows)}
        })


def judge_candidate(job):
    from lcb_runner.evaluation.compute_code_generation_metrics import evaluate_generations_by_problem

    qid, index, sample, code = job
    start = time.perf_counter()
    result, _ = evaluate_generations_by_problem(([code], sample, False, 6))
    verdict = result[0]
    return qid, index, bool(verdict) and all(value == True for value in verdict), time.perf_counter() - start


def judge():
    from concurrent.futures import ProcessPoolExecutor
    from tqdm import tqdm

    sys.path.insert(0, "/opt/eval/LiveCodeBench")
    from lcb_runner.benchmarks.code_generation import CodeGenerationProblem

    rows = problems()
    samples = {q["question_id"]: CodeGenerationProblem(**q).get_evaluation_sample()
               for q in rows}
    for generator in GENERATORS:
        if (OUT / f"timed_truth_{generator}.json").exists():
            continue
        candidates = read(f"generated_{generator}")
        jobs = [(qid, index, samples[qid], item["code"])
                for qid, items in candidates.items() for index, item in enumerate(items)]
        truth = {qid: [None] * K for qid in candidates}
        timing = {qid: [None] * K for qid in candidates}
        with ProcessPoolExecutor(max_workers=8) as executor:
            for qid, index, passed, seconds in tqdm(executor.map(judge_candidate, jobs),
                                                     total=len(jobs), desc=generator):
                truth[qid][index] = passed
                timing[qid][index] = seconds
        write(f"timed_truth_{generator}", {"truth": truth, "seconds": timing})


def summarize():
    rng = random.Random(SEED)
    output = {}
    for generator in GENERATORS:
        judged = read(f"timed_truth_{generator}")
        truth = judged["truth"]
        timing = judged["seconds"]
        generated = read(f"generated_{generator}")
        surrogate = read(f"scores_surrogate_{generator}")
        base = read(f"scores_base14b_{generator}")
        methods = {"surrogate": surrogate["problems"], "base_judge": base["problems"],
                   "generator": {qid: [x["mean_logprob"] for x in items]
                                 for qid, items in generated.items()}}
        curves = {}
        for budget in range(1, K + 1):
            random_hits = [1 - math.comb(K-sum(v), budget)/math.comb(K, budget)
                           for v in truth.values()]
            curves[budget] = {
                "random": statistics.mean(random_hits),
                "random_execution_seconds": statistics.mean(
                    budget * statistics.mean(values) for values in timing.values()),
            }
            for method, scores in methods.items():
                selected = {qid: sorted(range(K), key=lambda j: -scores[qid][j])[:budget]
                            for qid in truth}
                hits = [any(v[j] for j in selected[qid]) for qid, v in truth.items()]
                curves[budget][f"{method}_execution_seconds"] = statistics.mean(
                    sum(timing[qid][j] for j in indices) for qid, indices in selected.items())
                curves[budget][method] = statistics.mean(hits)
                if method == "surrogate":
                    delta = [h-r for h, r in zip(hits, random_hits)]
                    boot = sorted(statistics.mean(rng.choices(delta, k=N)) for _ in range(5000))
                    curves[budget]["surrogate_vs_random_ci"] = [boot[125], boot[4874]]
        for budget, point in curves.items():
            point["surrogate_vs_base_pp"] = 100 * (point["surrogate"] - point["base_judge"])
            point["surrogate_measured_work_s"] = (
                surrogate["seconds"] / N + point["surrogate_execution_seconds"])
        output[generator] = {
            "problems": N, "candidates_per_problem": K,
            "passing_candidates_histogram": [sum(sum(v) == i for v in truth.values())
                                             for i in range(K + 1)],
            "ranking_seconds": {"surrogate": surrogate["seconds"], "base_judge": base["seconds"]},
            "curves": curves,
        }
    write("summary", output)


if __name__ == "__main__":
    OUT.mkdir(exist_ok=True)
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("generate", "score", "judge", "summarize"))
    parser.add_argument("model", nargs="?", choices=MODELS)
    args = parser.parse_args()
    if args.stage in ("generate", "score"):
        inference(args.stage, args.model)
    elif args.stage == "judge":
        judge()
    else:
        summarize()
