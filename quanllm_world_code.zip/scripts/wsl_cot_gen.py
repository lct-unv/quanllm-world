# 反向推理 CoT 回填（SWE-World 式 reverse-reasoning distillation）
# teacher = V2.3 阶段一 SFT 模型（WSL2 vLLM FP8）
# 过滤纪律：结论与沙箱真实结果不一致 → 整条丢弃；CoT > 512 token → 整条丢弃
import json
import re
import sys

from vllm import LLM, SamplingParams
from transformers import AutoTokenizer

MODEL = "/mnt/e/quanllm-world/models/Qwen3-14B-v23-sft"
TRANSITIONS = "/mnt/e/quanllm-world/datasets/transitions.jsonl"
OUT = "/mnt/e/quanllm-world/datasets/cot.jsonl"
STATS = "/mnt/e/quanllm-world/datasets/cot.stats.json"

MAX_COT_TOKENS = 512
MAX_MODEL_LEN = 4096

PROMPT = """下面是一段代码、对它施加的一处变异、以及变异后代码在单元测试中的真实执行结果。

【原代码】
```python
{orig}
```

【变异 diff】
```diff
{diff}
```

【单元测试】
{tests}

【沙箱真实执行结果】
{result}
最终判定：{verdict}

请严格按以下格式输出，不要输出任何其他内容，不要复述题目，不要使用"让我想想"式自语：
分析：<2-4 句，指出变异改变了什么行为、导致哪个用例如何失败（或为何仍能通过）>
结论：通过 或 结论：不通过（必须与真实判定一致）。"""

CONCL = re.compile(r"结论[:：]\s*(通过|不通过)\s*$", re.M)


def tests_repr(t):
    if t["format"] == "pytest":
        return "```python\n" + t["code"][:1500] + "\n```"
    parts = []
    for i, c in enumerate(t["cases"][:4]):
        parts.append(f"用例{i}: 输入 {c['input'][:200]!r} 期望输出 {c['expected'][:200]!r}")
    return "\n".join(parts)


def result_repr(per_test, verdict):
    lines = []
    for c in per_test[:6]:
        s = f"{c['name']}: {c['status']}"
        if c["status"] == "fail":
            s += f"（{c['exc']}）"
        lines.append(s)
    if len(per_test) > 6:
        lines.append(f"……共 {len(per_test)} 条用例")
    return "\n".join(lines), "通过" if verdict == "pass" else "不通过"


def main():
    limit = int(sys.argv[1]) if len(sys.argv) > 1 else None
    rows = []
    with open(TRANSITIONS, encoding="utf-8") as f:
        for line in f:
            rows.append(json.loads(line))
            if limit and len(rows) >= limit:
                break
    print(f"transitions: {len(rows)}", flush=True)

    tok = AutoTokenizer.from_pretrained(MODEL)
    prompts = []
    for d in rows:
        res, verdict_zh = result_repr(d["result"]["per_test"], d["result"]["verdict"])
        body = PROMPT.format(
            orig=d["original_code"][:2500], diff=d["diff"][:1200],
            tests=tests_repr(d["tests"]), result=res, verdict=verdict_zh)
        msgs = [{"role": "user", "content": body}]
        prompts.append(tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True,
                                               enable_thinking=False))

    llm = LLM(model=MODEL, quantization="fp8", max_model_len=MAX_MODEL_LEN,
              gpu_memory_utilization=0.88, enforce_eager=False)
    sp = SamplingParams(temperature=0.4, top_p=0.9, max_tokens=900)
    outs = llm.generate(prompts, sp)

    n_ok = n_mismatch = n_long = n_noconcl = 0
    debug_rejects = []
    with open(OUT, "w", encoding="utf-8") as f:
        for d, o in zip(rows, outs):
            cot = o.outputs[0].text.strip()
            m = CONCL.search(cot)
            if not m:
                n_noconcl += 1
                if len(debug_rejects) < 6:
                    debug_rejects.append(cot[-100:])
                continue
            concl_pass = m.group(1) == "通过"
            if concl_pass != (d["result"]["verdict"] == "pass"):
                n_mismatch += 1
                continue
            n_tok = len(tok.encode(cot))
            if n_tok > MAX_COT_TOKENS:
                n_long += 1
                continue
            f.write(json.dumps({
                "id": d["id"], "src_idx": d["src_idx"], "op": d["op"],
                "verdict": d["result"]["verdict"], "cot": cot, "cot_tokens": n_tok,
            }, ensure_ascii=False) + "\n")
            n_ok += 1
    stats = {"in": len(rows), "kept": n_ok, "drop_mismatch": n_mismatch,
             "drop_over512": n_long, "drop_no_conclusion": n_noconcl}
    with open(STATS, "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=1)
    print(json.dumps(stats, ensure_ascii=False, indent=1), flush=True)
    for r in debug_rejects:
        print("REJECT-TAIL:", repr(r), flush=True)


if __name__ == "__main__":
    main()
