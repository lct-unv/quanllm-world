"""Audit structured output coverage and outcome accuracy on the archived dev split."""
import json
import re
from pathlib import Path

from stage3_analysis import load_gt, load_preds, macro_transition_acc, parse_transition

ROOT = Path(__file__).resolve().parents[1]


def reward_verdict(text):
    # Decode complete reports. A nested per-test verdict does not describe a suite.
    for start in re.finditer(r"\{", text):
        try:
            report, end = json.JSONDecoder().raw_decode(text[start.start():])
        except ValueError:
            continue
        if {"total", "passed", "failed", "per_test", "verdict"} <= report.keys():
            verdict = str(report["verdict"]).lower()
            return {"passed": "pass", "failed": "fail"}.get(verdict, verdict)
        # An outer JSON report was found; ignore its inner objects.
        return None
    return None


def main():
    transitions, rewards = load_gt()
    summary = {"total": len(rewards)}
    for name in ("surrogate", "baseline", "coder7b"):
        predictions = load_preds(ROOT / "datasets" / f"eval_pred_{name}.jsonl")
        complete = 0
        for mid, row in transitions.items():
            text = predictions.get(mid, {}).get("transition", {}).get("text", "")
            cases, _ = parse_transition(text)
            expected = {case["name"] for case in row["result"]["per_test"]}
            complete += bool(expected) and expected.issubset(cases)
        accuracy, n, _ = macro_transition_acc(predictions, transitions)
        valid = hits = 0
        for mid, row in rewards.items():
            text = predictions.get(mid, {}).get("reward", {}).get("text", "")
            verdict = reward_verdict(text)
            valid += verdict in ("pass", "fail")
            hits += verdict == row["verdict"]
        summary[name] = {
            "transition_full_coverage": complete,
            "transition_accuracy": accuracy,
            "transition_scored": n,
            "reward_complete_reports": valid,
            "reward_correct_reports": hits,
        }
    (ROOT / "data/dev_audit.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
