# AST 变异算子库（白名单内）：语句删除 / 相邻语句交换 / 运算符扰动 / 常量扰动 / 条件边界翻转 / 变量重命名
# 所有算子输出经 ast.unparse + ast.parse 复验，保证语法合法。
# fail 侧算子提供 _all 变体：枚举全部单位点变异，供无放回抽样，保证产出率。
import ast
import builtins
import keyword
import random

BUILTIN_NAMES = set(dir(builtins)) | set(keyword.kwlist)


def _collect_names(tree):
    names = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.Name):
            names.add(n.id)
        elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            names.add(n.name)
        elif isinstance(n, ast.Import):
            names.update(a.asname or a.name.split(".")[0] for a in n.names)
        elif isinstance(n, ast.ImportFrom):
            names.update(a.asname or a.name for a in n.names)
    return names


def _params(tree):
    out = set()
    for n in ast.walk(tree):
        if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
            a = n.args
            out.update(x.arg for x in a.posonlyargs + a.args + a.kwonlyargs)
            if a.vararg:
                out.add(a.vararg.arg)
            if a.kwarg:
                out.add(a.kwarg.arg)
    return out


def _syntax_ok(src):
    try:
        ast.parse(src)
        return True
    except SyntaxError:
        return False


def mut_rename(src, rng):
    """变量名同作用域替换（行为保持）。只改赋值变量，不碰参数/导入名/内置名。"""
    tree = ast.parse(src)
    params, existing = _params(tree), _collect_names(tree)
    assigned = {}
    for n in ast.walk(tree):
        if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store):
            assigned[n.id] = assigned.get(n.id, 0) + 1
    cands = [k for k in assigned if k not in params and k not in BUILTIN_NAMES
             and not k.startswith("__") and k.isidentifier()]
    if not cands:
        return None
    old = rng.choice(sorted(cands))
    new = None
    for _ in range(50):
        cand = f"{old}__m{rng.randint(0, 9999)}"
        if cand not in existing:
            new = cand
            break
    if new is None:
        return None

    class R(ast.NodeTransformer):
        def visit_Name(self, node):
            if node.id == old:
                node.id = new
            return node

    return ast.unparse(R().visit(tree))


def _rw(stmt):
    r, w = set(), set()
    for n in ast.walk(stmt):
        if isinstance(n, ast.Name):
            if isinstance(n.ctx, ast.Store):
                w.add(n.id)
                if isinstance(stmt, ast.AugAssign):
                    r.add(n.id)
            elif isinstance(n.ctx, ast.Load):
                r.add(n.id)
    return r, w


def _pure(stmt):
    if not isinstance(stmt, (ast.Assign, ast.AnnAssign)):
        return False
    return not any(isinstance(n, (ast.Call, ast.Yield, ast.YieldFrom, ast.Await,
                                  ast.Global, ast.Nonlocal)) for n in ast.walk(stmt))


def _stmt_lists(tree):
    lists = []
    for n in ast.walk(tree):
        for attr in ("body", "orelse", "finalbody"):
            b = getattr(n, attr, None)
            if isinstance(b, list) and len(b) >= 2:
                lists.append(b)
    return lists


def _swap_pair(src, lst_idx, pos):
    tree = ast.parse(src)
    lst = _stmt_lists(tree)[lst_idx]
    lst[pos], lst[pos + 1] = lst[pos + 1], lst[pos]
    return ast.unparse(tree)


def swap_all(src, require_independent):
    """相邻语句交换的全部单位点变体。require_independent=True 时只收无数据依赖的纯赋值对。"""
    tree = ast.parse(src)
    out = []
    for li, b in enumerate(_stmt_lists(tree)):
        for i in range(len(b) - 1):
            a, c = b[i], b[i + 1]
            if isinstance(a, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) or \
               isinstance(c, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                continue
            if require_independent:
                if not (_pure(a) and _pure(c)):
                    continue
                ra, wa = _rw(a)
                rc, wc = _rw(c)
                if wa & (rc | wc) or wc & (ra | wa):
                    continue
            m = _swap_pair(src, li, i)
            if _syntax_ok(m):
                out.append(m)
    return sorted(set(out))


_BINOP_FLIP = {ast.Add: ast.Sub, ast.Sub: ast.Add, ast.BitAnd: ast.BitOr, ast.BitOr: ast.BitAnd}
_CMP_FLIP = {ast.Lt: ast.LtE, ast.LtE: ast.Lt, ast.Gt: ast.GtE, ast.GtE: ast.Gt,
             ast.Eq: ast.NotEq, ast.NotEq: ast.Eq}


def _all_sites(src, site_pred, make_mutant):
    """枚举每个命中节点各生成一个变体，去重后返回。"""
    tree = ast.parse(src)
    sites = [n for n in ast.walk(tree) if site_pred(n)]
    out = []
    for k in range(len(sites)):
        t2 = ast.parse(src)
        s2 = [n for n in ast.walk(t2) if site_pred(n)]
        if k >= len(s2):
            break
        make_mutant(s2[k])
        new_src = ast.unparse(t2)
        if _syntax_ok(new_src):
            out.append(new_src)
    return sorted(set(out))


def binop_all(src):
    """算术/逻辑/比较运算符扰动（类型合法：+↔−、&↔|、and↔or、比较翻转）。"""
    out = _all_sites(
        src,
        lambda n: isinstance(n, ast.BinOp) and type(n.op) in _BINOP_FLIP,
        lambda n: setattr(n, "op", _BINOP_FLIP[type(n.op)]()))
    out += _all_sites(
        src,
        lambda n: isinstance(n, ast.BoolOp),
        lambda n: setattr(n, "op", ast.Or() if isinstance(n.op, ast.And) else ast.And()))
    out += _all_sites(
        src,
        lambda n: isinstance(n, ast.Compare) and len(n.ops) == 1 and type(n.ops[0]) in _CMP_FLIP,
        lambda n: setattr(n, "ops", [_CMP_FLIP[type(n.ops[0])]()]))
    return sorted(set(out))


def const_all(src):
    """常量扰动：每个数值常量 ±1 或 ×2（随机取一），字符串常量大小写翻转。"""
    rng = random.Random(0)
    def num_mut(n):
        if n.value == 0:
            n.value = 1
        else:
            n.value = rng.choice([n.value + 1, n.value - 1, n.value * 2])
    out = _all_sites(
        src,
        lambda n: isinstance(n, ast.Constant) and isinstance(n.value, int)
        and not isinstance(n.value, bool) and abs(n.value) < 10**9,
        num_mut)
    out += _all_sites(
        src,
        lambda n: isinstance(n, ast.Constant) and isinstance(n.value, str)
        and 0 < len(n.value) <= 40 and n.value.isascii(),
        lambda n: setattr(n, "value", n.value.swapcase()))
    return sorted(set(out))


def boundary_all(src):
    """条件边界翻转：if/while 内比较 < ↔ <= 等；range() 边界 ±1。"""
    out = _all_sites(
        src,
        lambda n: isinstance(n, (ast.If, ast.While)) and isinstance(n.test, ast.Compare)
        and len(n.test.ops) == 1 and type(n.test.ops[0]) in _CMP_FLIP,
        lambda n: setattr(n.test, "ops", [_CMP_FLIP[type(n.test.ops[0])]()]))
    out += _all_sites(
        src,
        lambda n: isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == "range"
        and 1 <= len(n.args) <= 2 and isinstance(n.args[-1], ast.Constant)
        and isinstance(n.args[-1].value, int) and not isinstance(n.args[-1].value, bool),
        lambda n: setattr(n.args[-1], "value", n.args[-1].value + 1))
    return sorted(set(out))


def delete_all(src):
    """语句删除（单行、非复合语句，且所在块至少 2 条）。"""
    tree = ast.parse(src)
    spots = []
    for li, b in enumerate(_stmt_lists(tree)):
        for i, s in enumerate(b):
            if isinstance(s, (ast.Assign, ast.AnnAssign, ast.AugAssign, ast.Expr, ast.Pass)):
                spots.append((li, i))
    out = []
    for li, i in spots:
        t2 = ast.parse(src)
        del _stmt_lists(t2)[li][i]
        new_src = ast.unparse(t2)
        if _syntax_ok(new_src):
            out.append(new_src)
    return sorted(set(out))


def gen_pass_candidate(code, rng):
    """1 个应仍通过变异：变量重命名优先，独立语句交换兜底。"""
    m = mut_rename(code, rng)
    if m and m != code and _syntax_ok(m):
        return m, "rename"
    sw = swap_all(code, True)
    if sw:
        return sw[0], "swap_indep"
    return None, None


def gen_fail_candidates(code, rng):
    """全部去重后的行为改变型候选（洗牌），供执行验证逐个取用。"""
    seen = {code}
    pools = []
    for op, fn in [("delete", delete_all), ("swap", lambda s: swap_all(s, False)),
                   ("binop", binop_all), ("const", const_all), ("boundary", boundary_all)]:
        for cand in fn(code):
            if cand not in seen:
                seen.add(cand)
                pools.append((cand, op))
    rng.shuffle(pools)
    return pools
