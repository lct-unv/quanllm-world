#!/bin/bash
set -euo pipefail
cd /mnt/e/quanllm-world
export VLLM_USE_DEEP_GEMM=0 VLLM_USE_FLASHINFER_SAMPLER=0 VLLM_ATTENTION_BACKEND=FLASH_ATTN
v=/opt/vllm-env/bin/python
run() {
  echo "$(date -Iseconds) $*"
  "$v" -u scripts/rollout_eval.py "$@"
}
for model in coder7b base14b; do
  [ -f "outputs/rollout_eval/generated_$model.json" ] || run generate "$model"
done
for model in surrogate base14b; do
  if [ ! -f "outputs/rollout_eval/scores_${model}_coder7b.json" ] || [ ! -f "outputs/rollout_eval/scores_${model}_base14b.json" ]; then
    run score "$model"
  fi
done
/opt/eval-env/bin/python -u scripts/rollout_eval.py judge
run summarize
echo "ROLLOUT DONE"
