# Injected via PYTHONPATH into sandboxed processes: blocks outbound network at
# the Python level by replacing the socket entry points before user code runs.
import socket

def _blocked(*args, **kwargs):
    raise OSError("network disabled in sandbox")

class _BlockedSocket(socket.socket):
    def __init__(self, *args, **kwargs):
        raise OSError("network disabled in sandbox")

socket.socket = _BlockedSocket
socket.create_connection = _blocked
