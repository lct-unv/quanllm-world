# D1 对照数据集：单任务 10% 抽样（transition-only / reward-only），复用主构建函数
import json
import random
import sys

import pyarrow as pa
import pyarrow.parquet as pq

sys.path.insert(0, r"E:\quanllm-world\scripts")
from build_training_data import build_samples, tokenize_sample, pack_split, DATA, MAX_LEN, TOK  # noqa

random.seed(123)

def main():
    cot_map, transitions, rewards = {}, {}, {}
    with open(DATA + r"\cot.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            cot_map[d["id"]] = d
    with open(DATA + r"\transitions.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            transitions[d["id"]] = d
    with open(DATA + r"\rewards.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            rewards[d["id"]] = d

    # train split 的 mid 集合
    train_mids = set()
    t = pq.read_table(DATA + r"\packed\train.parquet", columns=["mids"])
    for mids in t.column("mids").to_pylist():
        train_mids.update(mids)

    src_of = {}
    with open(DATA + r"\mutants_clean.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            if d["mid"] in train_mids:
                src_of[d["mid"]] = d["src_idx"]

    srcs = sorted(set(src_of.values()))
    random.shuffle(srcs)
    keep_src = set(srcs[: max(1, len(srcs) // 10)])  # 按题 10%

    for task in ("transition", "reward"):
        samples = []
        for mid, src in src_of.items():
            if src not in keep_src:
                continue
            tr, rw, cot = transitions.get(mid), rewards.get(mid), cot_map.get(mid)
            if not tr or not rw:
                continue
            for tname, messages in build_samples(tr, rw, cot):
                if tname != task:
                    continue
                ids, labels = tokenize_sample(messages)
                if len(ids) <= MAX_LEN:
                    samples.append((ids, labels, tname, mid))
        packed = pack_split(samples)
        pq.write_table(pa.table({
            "input_ids": [p["input_ids"] for p in packed],
            "labels": [p["labels"] for p in packed],
            "n_samples": [p["n_samples"] for p in packed],
            "tasks": [p["tasks"] for p in packed],
            "mids": [p["mids"] for p in packed],
        }), DATA + rf"\packed\control_{task}.parquet")
        print(task, "samples:", len(samples), "seqs:", len(packed), flush=True)


if __name__ == "__main__":
    main()
