$ErrorActionPreference = 'Stop'
Set-Location E:/quanllm-world
$python = 'E:/quanllm-world/.venv/Scripts/python.exe'
function Invoke-Step {
    & $python -u @args
    if ($LASTEXITCODE -ne 0) { throw "Python exited with $LASTEXITCODE" }
}
foreach ($arm in @('joint','reward','no_rationale')) {
    $out = "outputs/ablations_short/$arm"
    $data = if ($arm -eq 'joint') { 'datasets/packed/train.parquet' } else { "datasets/packed/ablations/$arm.parquet" }
    if (-not (Test-Path "$out/final_adapter/tokenizer_config.json")) {
        Invoke-Step scripts/train_surrogate.py --matched_steps 20 --train_parquet $data --out_dir $out
    }
    if (-not (Test-Path "$out/merged/model.safetensors.index.json")) {
        Invoke-Step scripts/merge_any.py "$out/final_adapter" "$out/merged"
    }
}
foreach ($arm in @('joint','reward','no_rationale')) {
    if (-not (Test-Path "outputs/ablations_short/$arm/dev.jsonl")) {
        & wsl.exe -d Ubuntu -- bash /mnt/e/quanllm-world/scripts/run_short_ablation_eval.sh $arm
        if ($LASTEXITCODE -ne 0) { throw "WSL evaluation exited with $LASTEXITCODE" }
    }
}
Invoke-Step scripts/report_short_ablations.py
Write-Output 'SHORT ABLATIONS COMPLETE'
