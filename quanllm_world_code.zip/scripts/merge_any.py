# 通用 LoRA 合并：python merge_any.py <adapter_dir> <out_dir>
import sys
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

BASE = r"E:\quanllm-coder\models\Qwen3-14B"

def main():
    adapter, out = sys.argv[1], sys.argv[2]
    model = AutoModelForCausalLM.from_pretrained(BASE, dtype=torch.bfloat16, device_map="cpu")
    model = PeftModel.from_pretrained(model, adapter)
    model = model.merge_and_unload()
    model.save_pretrained(out)
    AutoTokenizer.from_pretrained(BASE).save_pretrained(out)
    print("MERGED ->", out)

if __name__ == "__main__":
    main()
