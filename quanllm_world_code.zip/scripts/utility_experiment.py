# 下游效用实验：替身引导的 rollout 预过滤（STaR 式沙箱预算场景）
# 场景：每题有 K 个候选解（变异体，含沙箱真值），沙箱预算 B=每题执行次数
#   - 随机基线：随机选 B 个执行
#   - 替身引导：按替身 P(pass) 排序选 top-B 执行
# 指标：命中率（选中的候选里至少一个真实通过）、AUC、以及达到同等产出所需的沙箱执行数对比
import json
import random
import re
import sys
from pathlib import Path
from collections import defaultdict

import pyarrow.parquet as pq

DATA = Path(__file__).resolve().parents[1] / "datasets"

CONCL = re.compile(r"结论[:：]\s*(通过|不通过)")


def main():
    # test 集 mid 集合
    t = pq.read_table(DATA / "packed/test.parquet", columns=["mids"])
    test_mids = set()
    for mids in t.column("mids").to_pylist():
        test_mids.update(mids)

    # 沙箱真值（reward verdict）
    gt = {}
    with open(DATA / "rewards.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            if d["id"] in test_mids:
                gt[d["id"]] = (d["verdict"] == "pass", d["src_idx"])

    # 替身预测（test 集 reward 任务：verdict + conf）
    pred = {}
    with open(DATA / "eval_pred_surrogate_test.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            if d["task"] != "reward":
                continue
            m = re.search(r"\"verdict\"\s*:\s*\"(pass|fail)\"", d["text"])
            pv = m.group(1) if m else None
            conf = d.get("verdict_conf")
            # P(pass)：判定为 pass 时取 conf，否则取 1-conf；无 conf 时退化为 0.5
            p_pass = (conf if pv == "pass" else (1 - conf if conf else 0.5)) if pv else 0.5
            pred[d["id"]] = p_pass

    # 按题分组
    by_src = defaultdict(list)
    for mid, (is_pass, src) in gt.items():
        if mid in pred:
            by_src[src].append((mid, is_pass, pred[mid]))

    rng = random.Random(0)
    results = {}
    for B in (1, 2):
        hit_rand = hit_surr = 0
        n = 0
        for src, cands in by_src.items():
            if len(cands) < B:
                continue
            n += 1
            for _ in range(200):  # 随机基线取期望
                pick = rng.sample(cands, B)
                hit_rand += any(c[1] for c in pick) / 200
            top = sorted(cands, key=lambda c: -c[2])[:B]
            hit_surr += any(c[1] for c in top)
        results[f"B={B}"] = {"problems": n,
                             "random_hit": round(hit_rand / n, 4),
                             "surrogate_hit": round(hit_surr / n, 4)}

    # 预过滤效率：替身判 pass 的候选中真实通过的比例（= 每单位沙箱执行的产出率提升）
    allc = [(p, g) for src, cs in by_src.items() for _, g, p in cs]
    pred_pass = [(p, g) for p, g in allc if p >= 0.5]
    prec = sum(1 for _, g in pred_pass if g) / max(1, len(pred_pass))
    base_rate = sum(1 for _, g in allc if g) / len(allc)
    # AUC（P(pass) 对真实 pass/fail 的排序质量）
    pos = sorted([p for p, g in allc if g])
    neg = sorted([p for p, g in allc if not g])
    wins = sum(1 for pp in pos for nn in neg if pp > nn) + 0.5 * sum(1 for pp in pos for nn in neg if pp == nn)
    auc = wins / (len(pos) * len(neg)) if pos and neg else None
    results["filtering"] = {"candidates": len(allc), "base_pass_rate": round(base_rate, 4),
                            "surrogate_filtered_precision": round(prec, 4),
                            "auc": round(auc, 4) if auc else None}
    print(json.dumps(results, ensure_ascii=False, indent=1))
    with open(DATA / "utility_test.json", "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
