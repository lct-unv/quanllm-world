# 阶段 3 评测生成：dev 集上用指定模型跑 transition + reward 预测（带 verdict token logprob）
# 用法: python wsl_eval_gen.py <model_path> <out_file> [limit]
import json
import re
import sys

import pyarrow.parquet as pq
from vllm import LLM, SamplingParams
from transformers import AutoTokenizer

MODEL = sys.argv[1]
OUT = sys.argv[2]
SPLIT = sys.argv[3] if len(sys.argv) > 3 and not sys.argv[3].isdigit() else "dev"
LIMIT = int(sys.argv[3]) if len(sys.argv) > 3 and sys.argv[3].isdigit() else (int(sys.argv[4]) if len(sys.argv) > 4 else None)

DATA = "/mnt/e/quanllm-world/datasets"

TRANS_USER = """下面是一段代码和即将对它施加的一处变异（diff），以及单元测试。请预测变异后代码在每个测试用例上的执行结果，先给出简洁分析，再逐用例给出预测，最后一行写"结论：通过"（全部通过）或"结论：不通过"。

【原代码】
```python
{orig}
```

【变异 diff】
```diff
{diff}
```

【单元测试】
{tests}"""

REWARD_USER = """下面是一段代码和它的单元测试。请评估该代码能否通过全部测试，输出结构化 JSON 报告（total/passed/failed/per_test/verdict）。

【代码】
```python
{code}
```

【单元测试】
{tests}"""


def tests_repr(t):
    if t["format"] == "pytest":
        return "```python\n" + t["code"] + "\n```"
    return "\n".join(f"用例{i}: 输入 {c['input']!r} 期望输出 {c['expected']!r}"
                     for i, c in enumerate(t["cases"]))


def verdict_logprob(output, kind):
    """从 token logprobs 里找判定 token 的概率。kind: 'transition' 找结论 token，'reward' 找 verdict 值。"""
    tokens = output.logprobs or []
    text = ""
    target_pos = None
    target_tok = None
    for i, lp in enumerate(tokens):
        best = max(lp.values(), key=lambda x: x.logprob) if lp else None
        dec = best.decoded_token if best else ""
        text += dec or ""
        if kind == "transition":
            if "通过" in (dec or ""):
                target_pos, target_tok = i, "通过"
        else:
            if re.fullmatch(r'"?(pass|fail)"?', (dec or "").strip()) and "verdict" in text:
                target_pos, target_tok = i, dec.strip().strip('"')
    if target_pos is None:
        return None, None
    import math
    best_id, best_lp = max(tokens[target_pos].items(), key=lambda kv: kv[1].logprob)
    return math.exp(best_lp.logprob), text


def main():
    dev = pq.read_table(f"{DATA}/packed/{SPLIT}.parquet", columns=["mids", "tasks"])
    dev_mids = set()
    for mids in dev.column("mids").to_pylist():
        dev_mids.update(mids)
    transitions, rewards = {}, {}
    with open(f"{DATA}/transitions.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            if d["id"] in dev_mids:
                transitions[d["id"]] = d
    with open(f"{DATA}/rewards.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            if d["id"] in dev_mids:
                rewards[d["id"]] = d

    trans_user = TRANS_USER
    if MODEL.rstrip("/").endswith("/no_rationale/merged"):
        trans_user = trans_user.replace("先给出简洁分析，再", "")
    tok = AutoTokenizer.from_pretrained(MODEL)
    jobs = []  # (id, kind, prompt)
    for mid in sorted(dev_mids):
        tr, rw = transitions.get(mid), rewards.get(mid)
        if not tr or not rw:
            continue
        jobs.append((mid, "transition", trans_user.format(
            orig=tr["original_code"], diff=tr["diff"], tests=tests_repr(tr["tests"]))))
        jobs.append((mid, "reward", REWARD_USER.format(
            code=rw["mutated_code"], tests=tests_repr(rw["tests"]))))
    if LIMIT:
        if "/ablations_short/" in MODEL:
            import random
            groups = list(zip(jobs[::2], jobs[1::2], strict=True))
            rng = random.Random(42)
            rng.shuffle(groups)
            jobs = [job for pair in groups[:LIMIT // 2] for job in pair]
        else:
            jobs = jobs[:LIMIT]
    print(f"eval jobs: {len(jobs)} (mids={len(dev_mids)})", flush=True)

    prompts = [tok.apply_chat_template([{"role": "user", "content": p}], tokenize=False,
                                       add_generation_prompt=True, enable_thinking=False)
               for _, _, p in jobs]
    llm = LLM(model=MODEL, quantization="fp8", max_model_len=4096,
              gpu_memory_utilization=0.85, enforce_eager=True,
              max_num_seqs=32, max_num_batched_tokens=4096)
    sp = SamplingParams(temperature=0.0, max_tokens=512 if "/ablations_short/" in MODEL else 900, logprobs=5)
    outs = llm.generate(prompts, sp)

    with open(OUT + ".tmp", "w", encoding="utf-8") as f:
        for (mid, kind, _), o in zip(jobs, outs):
            text = o.outputs[0].text
            conf, _ = verdict_logprob(o.outputs[0], kind)
            f.write(json.dumps({"id": mid, "task": kind, "text": text,
                                "verdict_conf": conf}, ensure_ascii=False) + "\n")
    from os import replace
    replace(OUT + ".tmp", OUT)
    print("GEN DONE ->", OUT, flush=True)


if __name__ == "__main__":
    main()
