"""Repack the archived training split for three controlled comparisons."""
import gc
import json
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq

from build_training_data import DATA, MAX_LEN, build_samples, pack_split, tokenize_sample

root = Path(DATA)
out = root / "packed" / "ablations"


def load(name, mids):
    with (root / f"{name}.jsonl").open(encoding="utf-8") as file:
        return {row["id"]: row for row in map(json.loads, file) if row["id"] in mids}


def main():
    out.mkdir(exist_ok=True)
    table = pq.read_table(root / "packed/train.parquet", columns=["mids", "tasks"])
    pairs = {(mid, task) for mids, tasks in zip(table["mids"].to_pylist(), table["tasks"].to_pylist())
             for mid, task in zip(mids, tasks, strict=True)}
    mids = {mid for mid, _ in pairs}
    transition = load("transitions", mids)
    reward = load("rewards", mids)
    rationale = load("cot", mids)
    manifest = {}
    for arm in ("transition", "reward", "no_rationale"):
        path = out / f"{arm}.parquet"
        samples = []
        for mid in sorted(mids):
            for task, messages in build_samples(transition[mid], reward[mid], rationale.get(mid)):
                if (mid, task) not in pairs or arm not in (task, "no_rationale"):
                    continue
                if arm == "no_rationale" and task == "transition":
                    target = messages[-1]["content"]
                    marker = "\u9010\u7528\u4f8b\u9884\u6d4b\uff1a"
                    messages[-1]["content"] = marker + target.rsplit(marker, 1)[1]
                    messages[0]["content"] = messages[0]["content"].replace(
                        "\u5148\u7ed9\u51fa\u7b80\u6d01\u5206\u6790\uff0c\u518d", "")
                ids, labels = tokenize_sample(messages)
                if len(ids) > MAX_LEN:
                    raise ValueError((mid, task, len(ids)))
                samples.append((ids, labels, task, mid))
        packed = pack_split(samples)
        expected = {pair for pair in pairs if arm in (pair[1], "no_rationale")}
        assert {(mid, task) for _, _, task, mid in samples} == expected
        tmp = path.with_suffix(".tmp")
        pq.write_table(pa.Table.from_pylist(packed), tmp)
        tmp.replace(path)
        manifest[arm] = {"samples": len(samples), "sequences": len(packed),
                         "tokens": sum(len(ids) for ids, *_ in samples)}
        print(arm, manifest[arm], flush=True)
        del packed, samples
        gc.collect()
    (out / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
