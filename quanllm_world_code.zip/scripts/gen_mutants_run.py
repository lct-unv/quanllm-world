# 变异生成驱动：对源池每题生成 K=4 个变异体并在沙箱中执行验证。
# 约束落实：
#   - 语法合法：AST 变换 + ast.parse 复验（mutate.py 内）
#   - 每题 >=1 个"应仍通过"变异：rename 生成后必须实测通过，否则重试/兜底，兜底不成则该题不出库
#   - 标签 = 实际执行结果；总量目标 ~55K，pass 比例目标 15-25%（超出则裁剪 survived 的行为改变型）
import json
import os
import random
import sys
import tempfile
import time
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sandbox import run_sandboxed
from filter_pool import extract_code, output_matches, SIDE_EFFECT_PAT, PY, qkey
from extract_tests import extract_tests
from mutate import gen_pass_candidate, gen_fail_candidates, mut_rename, swap_all

POOL = r"E:\quanllm-world\datasets\source_pool_filtered.jsonl"
TEST_MAP = r"E:\quanllm-world\datasets\kodcode_tests.jsonl"
OUT = r"E:\quanllm-world\datasets\mutants.jsonl"
STATS = r"E:\quanllm-world\datasets\mutants.stats.json"

TEST_TIMEOUT_S = 5.0
JOB_MEM_MB = 1024


def exec_io(code, tests, idx):
    total = 0.0
    with tempfile.TemporaryDirectory(prefix=f"mut{idx}_") as td:
        sol = os.path.join(td, "sol.py")
        with open(sol, "w", encoding="utf-8") as f:
            f.write(code)
        for stdin_data, expected in tests:
            r = run_sandboxed([PY, sol], timeout_s=TEST_TIMEOUT_S, job_mem_mb=JOB_MEM_MB,
                              block_net=True, cwd=td, extra_env={"PYTHONIOENCODING": "utf-8"},
                              stdin_data=stdin_data)
            total += r["elapsed_s"]
            if r["timed_out"] or r["rc"] != 0 or not output_matches(r["output"], expected):
                return False, total
    return True, total


def exec_pytest(code, test_code, idx):
    import re as _re
    def _attempt(text):
        with tempfile.TemporaryDirectory(prefix=f"mut{idx}_") as td:
            open(os.path.join(td, "solution.py"), "w", encoding="utf-8").write(text)
            open(os.path.join(td, "test_main.py"), "w", encoding="utf-8").write(test_code)
            r = run_sandboxed([PY, "-m", "pytest", "test_main.py", "-q", "--tb=no", "-p", "no:cacheprovider"],
                              timeout_s=TEST_TIMEOUT_S, job_mem_mb=JOB_MEM_MB, block_net=True, cwd=td)
            return r
    r = _attempt(code)
    if r["rc"] == 2 and not r["timed_out"]:
        imp = _re.compile(r"^\s*from\s+solution\s+import\s+(.+)$", _re.M)
        imported = set()
        for m in imp.finditer(test_code):
            imported.update(x.strip().split(" as ")[0] for x in m.group(1).split(","))
        defined = _re.compile(r"^def\s+(\w+)\s*\(", _re.M).findall(code)
        missing = imported - set(defined)
        if missing and len(defined) == 1:
            alias = code + "\n" + "\n".join(f"{m} = {defined[0]}" for m in missing) + "\n"
            r = _attempt(alias)
    return (r["rc"] == 0 and not r["timed_out"]), r["elapsed_s"]


def exec_check(mode, code, payload, idx):
    if mode == "pytest":
        return exec_pytest(code, payload, idx)
    return exec_io(code, payload, idx)


def work(args):
    idx, mode, code, payload = args
    rng = random.Random(1000003 * idx + 7)
    rows = []

    # 1 个应仍通过（实测必须真通过；失败换名重试，再兜底独立交换）
    pass_ok = False
    for _ in range(6):
        m, op = gen_pass_candidate(code, rng)
        if not m:
            break
        actual, rt = exec_check(mode, m, payload, idx)
        if actual:
            rows.append({"src_idx": idx, "op": op, "expect_pass": True,
                         "actual_pass": True, "runtime_s": round(rt, 2), "code": m})
            pass_ok = True
            break
    if not pass_ok:
        return idx, [], 0

    # 3 个行为改变型：逐个执行验证，幸存者立即用候选池补位重抽，保证留下的都被测试杀死
    killed, tried, n_surv = 0, 0, 0
    for cand, op in gen_fail_candidates(code, rng):
        if killed >= 3 or tried >= 9:
            break
        tried += 1
        actual, rt = exec_check(mode, cand, payload, idx)
        if actual:
            n_surv += 1
            continue
        rows.append({"src_idx": idx, "op": op, "expect_pass": False,
                     "actual_pass": False, "runtime_s": round(rt, 2), "code": cand})
        killed += 1
    return idx, rows, n_surv


def main(limit=None, workers=12):
    test_map = {}
    with open(TEST_MAP, encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            test_map[d["k"]] = d["test"]

    jobs = []
    with open(POOL, encoding="utf-8") as f:
        for i, line in enumerate(f):
            if limit and i >= limit:
                break
            d = json.loads(line)
            code = extract_code(d["messages"][-1]["content"])
            if not code or SIDE_EFFECT_PAT.search(code):
                continue
            tc = test_map.get(qkey(d["messages"][0]["content"]))
            if tc:
                jobs.append((i, "pytest", code, tc))
                continue
            tests = extract_tests(d["messages"][0]["content"])
            if tests:
                jobs.append((i, "io", code, tests))
    print(f"problems: {len(jobs)}", flush=True)

    t0 = time.time()
    all_rows, no_pass_problems, total_surv = [], 0, 0
    with Pool(workers) as pool:
        for done, (idx, rows, n_surv) in enumerate(pool.imap_unordered(work, jobs, chunksize=2)):
            total_surv += n_surv
            if rows:
                all_rows.extend(rows)
            else:
                no_pass_problems += 1
            if done % 1000 == 0:
                print(f"  {done}/{len(jobs)} mutants={len(all_rows)} elapsed={time.time()-t0:.0f}s", flush=True)

    n_pass = sum(1 for r in all_rows if r["actual_pass"])
    ratio = n_pass / max(1, len(all_rows))

    with open(OUT, "w", encoding="utf-8") as f:
        for r in all_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    from collections import Counter
    stats = {
        "problems_in": len(jobs),
        "problems_dropped_no_pass": no_pass_problems,
        "mutants_total": len(all_rows),
        "mutants_per_problem": round(len(all_rows) / max(1, len(jobs) - no_pass_problems), 2),
        "pass_count": n_pass, "pass_ratio": round(ratio, 4),
        "survived_and_replaced": total_surv,
        "op_dist": dict(Counter(r["op"] for r in all_rows)),
        "wall_time_s": round(time.time() - t0, 1),
    }
    with open(STATS, "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=1)
    print(json.dumps(stats, ensure_ascii=False, indent=1), flush=True)


if __name__ == "__main__":
    main(limit=int(sys.argv[1]) if len(sys.argv) > 1 else None)
