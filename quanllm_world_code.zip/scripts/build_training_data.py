# 3.6 切分与打包
# - 按源题（src_idx）切分 train/dev/test = 92/4/4，同题所有变异体同集合（防跨集泄漏）
# - 长度过滤：单样本（chat 模板展开后）> 4096 token 整条丢弃，不截断
# - 双任务混排：transition 与 reward 样本混合
# - packing 纪律：离线物化 packed 序列（input_ids + labels，prompt 部分 -100 掩码），
#   每序列样本数落盘统计；不依赖 TRL/Unsloth 的 packing 开关，杜绝静默绕过
import json
import random
import re
import sys
from collections import Counter

import pyarrow as pa
import pyarrow.parquet as pq
from transformers import AutoTokenizer

TOK = AutoTokenizer.from_pretrained(r"E:\quanllm-coder\models\Qwen3-14B")
MAX_LEN = 4096
SEED = 42
DATA = r"E:\quanllm-world\datasets"
OUT = DATA + r"\packed"

TRANS_USER = """下面是一段代码和即将对它施加的一处变异（diff），以及单元测试。请预测变异后代码在每个测试用例上的执行结果，先给出简洁分析，再逐用例给出预测，最后一行写"结论：通过"（全部通过）或"结论：不通过"。

【原代码】
```python
{orig}
```

【变异 diff】
```diff
{diff}
```

【单元测试】
{tests}"""

REWARD_USER = """下面是一段代码和它的单元测试。请评估该代码能否通过全部测试，输出结构化 JSON 报告（total/passed/failed/per_test/verdict）。

【代码】
```python
{code}
```

【单元测试】
{tests}"""

CONCL_STRIP = re.compile(r"\n*结论[:：]\s*(通过|不通过)\s*$")


def tests_repr(t):
    if t["format"] == "pytest":
        return "```python\n" + t["code"] + "\n```"
    return "\n".join(f"用例{i}: 输入 {c['input']!r} 期望输出 {c['expected']!r}"
                     for i, c in enumerate(t["cases"]))


def build_samples(tr, rw, cot):
    """每个变异体产出最多 2 个训练样本（transition 需 CoT；reward 不需要）。"""
    out = []
    if cot:
        body = CONCL_STRIP.sub("", cot["cot"]).strip()
        per_test = "\n".join(
            f"- {c['name']}: {c['status']}" + (f"（{c['exc']}）" if c.get("exc") else "")
            for c in tr["result"]["per_test"])
        verdict_zh = "通过" if tr["result"]["verdict"] == "pass" else "不通过"
        out.append(("transition", [
            {"role": "user", "content": TRANS_USER.format(
                orig=tr["original_code"], diff=tr["diff"],
                tests=tests_repr(tr["tests"]))},
            {"role": "assistant", "content": f"{body}\n\n逐用例预测：\n{per_test}\n结论：{verdict_zh}"},
        ]))
    rep = rw["report"]
    compact = {"total": rep["total"], "passed": rep["passed"], "failed": rep["failed"],
               "per_test": [{"name": c["name"], "status": c["status"], "exc": c["exc"]}
                            for c in rep["per_test"]],
               "verdict": rw["verdict"]}
    out.append(("reward", [
        {"role": "user", "content": REWARD_USER.format(
            code=rw["mutated_code"], tests=tests_repr(rw["tests"]))},
        {"role": "assistant", "content": json.dumps(compact, ensure_ascii=False)},
    ]))
    return out


def tokenize_sample(messages):
    prompt_text = TOK.apply_chat_template(messages[:-1], tokenize=False,
                                          add_generation_prompt=True, enable_thinking=False)
    resp_text = messages[-1]["content"] + "<|im_end|>\n"
    p_ids = TOK(prompt_text, add_special_tokens=False)["input_ids"]
    r_ids = TOK(resp_text, add_special_tokens=False)["input_ids"]
    return p_ids + r_ids, [-100] * len(p_ids) + r_ids


def pack_split(samples, max_len=MAX_LEN):
    """first-fit decreasing 装箱；samples: [(ids, labels, task, mid)]。
    返回 packed: [dict]，并做自洽校验。"""
    order = sorted(samples, key=lambda s: -len(s[0]))
    bins = []          # 每个元素: [ids, labels, tasks(list), mid list]
    bin_free = []
    for ids, labels, task, mid in order:
        placed = False
        for bi in range(len(bins) - 1, max(len(bins) - 41, -1), -1):  # 只看最近 40 个箱
            if bin_free[bi] >= len(ids):
                bins[bi][0].extend(ids)
                bins[bi][1].extend(labels)
                bins[bi][2].append(task)
                bins[bi][3].append(mid)
                bin_free[bi] -= len(ids)
                placed = True
                break
        if not placed:
            bins.append([list(ids), list(labels), [task], [mid]])
            bin_free.append(max_len - len(ids))
    return [{"input_ids": b[0], "labels": b[1], "n_samples": len(b[2]),
             "tasks": b[2], "mids": b[3]} for b in bins]


def main():
    random.seed(SEED)
    cot_map, transitions, rewards = {}, {}, {}
    with open(DATA + r"\cot.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            cot_map[d["id"]] = d
    with open(DATA + r"\transitions.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            transitions[d["id"]] = d
    with open(DATA + r"\rewards.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            rewards[d["id"]] = d

    # 按源题切分 92/4/4
    srcs = set()
    rows = []
    with open(DATA + r"\mutants_clean.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            rows.append(d)
            srcs.add(d["src_idx"])
    srcs = sorted(srcs)
    random.shuffle(srcs)
    n = len(srcs)
    n_dev = max(1, round(n * 0.04))
    n_test = max(1, round(n * 0.04))
    split_of = {}
    for s in srcs[:n - n_dev - n_test]:
        split_of[s] = "train"
    for s in srcs[n - n_dev - n_test:n - n_test]:
        split_of[s] = "dev"
    for s in srcs[n - n_test:]:
        split_of[s] = "test"
    print(f"problems: {n} -> train {n-n_dev-n_test} / dev {n_dev} / test {n_test}", flush=True)

    # 构建 + tokenize + 长度过滤
    per_split = {"train": [], "dev": [], "test": []}
    drop_long = Counter()
    no_cot_transition = 0
    for k, d in enumerate(rows):
        mid, src = d["mid"], d["src_idx"]
        split = split_of[src]
        tr, rw, cot = transitions.get(mid), rewards.get(mid), cot_map.get(mid)
        if not tr or not rw:
            continue
        if not cot:
            no_cot_transition += 1
        for task, messages in build_samples(tr, rw, cot):
            ids, labels = tokenize_sample(messages)
            if len(ids) > MAX_LEN:
                drop_long[task] += 1
                continue
            per_split[split].append((ids, labels, task, mid))
        if k % 5000 == 0:
            print(f"  tokenized {k}/{len(rows)}", flush=True)

    # 打包 + 落盘
    import os
    os.makedirs(OUT, exist_ok=True)
    report = {"split_problems": {"train": n - n_dev - n_test, "dev": n_dev, "test": n_test},
              "drop_over_4096": dict(drop_long),
              "transition_skipped_no_cot": no_cot_transition,
              "max_len": MAX_LEN, "splits": {}}
    for split, samples in per_split.items():
        packed = pack_split(samples)
        n_samples = sum(p["n_samples"] for p in packed)
        assert n_samples == len(samples), f"{split}: packed 样本数 {n_samples} != 输入 {len(samples)}"
        assert all(len(p["input_ids"]) <= MAX_LEN for p in packed)
        assert all(len(p["input_ids"]) == len(p["labels"]) for p in packed)
        counts = [p["n_samples"] for p in packed]
        seq_lens = [len(p["input_ids"]) for p in packed]
        task_mix = Counter(t for p in packed for t in p["tasks"])
        report["splits"][split] = {
            "samples": len(samples), "packed_seqs": len(packed),
            "samples_per_seq": {"mean": round(sum(counts) / len(counts), 2),
                                "min": min(counts), "max": max(counts)},
            "seq_len": {"mean": int(sum(seq_lens) / len(seq_lens)),
                        "p50": sorted(seq_lens)[len(seq_lens) // 2], "max": max(seq_lens)},
            "task_mix": dict(task_mix),
        }
        pq.write_table(pa.table({
            "input_ids": [p["input_ids"] for p in packed],
            "labels": [p["labels"] for p in packed],
            "n_samples": [p["n_samples"] for p in packed],
            "tasks": [p["tasks"] for p in packed],
            "mids": [p["mids"] for p in packed],
        }), OUT + rf"\{split}.parquet")
        print(split, report["splits"][split], flush=True)

    with open(DATA + r"\pack_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=1)
    print(json.dumps(report, ensure_ascii=False, indent=1)[:1500], flush=True)


if __name__ == "__main__":
    main()
