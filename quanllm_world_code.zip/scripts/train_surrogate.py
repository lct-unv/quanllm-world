# 阶段 2 替身模型训练：Qwen3-14B 4-bit QLoRA r=32/all-linear，离线 packed 数据直读
# 用法：试训 python train_surrogate.py --max_steps 24
#       正式 python train_surrogate.py（1 epoch，195 步，每 1/4 存 adapter）
import argparse
import json
import os
import time

# triton-windows 的 C 层 getenv 会把含中文的用户路径按 GBK 取出再按 UTF-8 解码而崩溃，
# 统一指到纯 ASCII 路径规避。
for _k, _v in {
    "TRITON_HOME": r"E:\quanllm-world\cache\triton\home",
    "TRITON_CACHE_DIR": r"E:\quanllm-world\cache\triton\cache",
    "TRITON_DUMP_DIR": r"E:\quanllm-world\cache\triton\dump",
    "TRITON_OVERRIDE_DIR": r"E:\quanllm-world\cache\triton\override",
}.items():
    os.environ.setdefault(_k, _v)

import pyarrow.parquet as pq
import torch
from torch.utils.data import Dataset
from transformers import AutoTokenizer, Trainer, TrainingArguments, TrainerCallback

BASE = r"E:\quanllm-coder\models\Qwen3-14B"
DATA_DIR = r"E:\quanllm-world\datasets\packed"
OUT_DIR = r"E:\quanllm-world\outputs\surrogate_sft"
ACCUM = 64          # 64 条 packed 序列/步（≈522 样本）
LR = 1e-4


class PackedDS(Dataset):
    def __init__(self, path):
        t = pq.read_table(path, columns=["input_ids", "labels"])
        self.ids = t.column("input_ids").to_pylist()
        self.lbl = t.column("labels").to_pylist()

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, i):
        return {"input_ids": torch.tensor(self.ids[i], dtype=torch.long),
                "labels": torch.tensor(self.lbl[i], dtype=torch.long)}


def collate(feats):
    maxlen = max(len(f["input_ids"]) for f in feats)
    input_ids, labels, attn = [], [], []
    for f in feats:
        n = maxlen - len(f["input_ids"])
        input_ids.append(torch.cat([f["input_ids"], torch.full((n,), 151643, dtype=torch.long)]))
        labels.append(torch.cat([f["labels"], torch.full((n,), -100, dtype=torch.long)]))
        attn.append(torch.cat([torch.ones(len(f["input_ids"]), dtype=torch.long),
                               torch.zeros(n, dtype=torch.long)]))
    return {"input_ids": torch.stack(input_ids), "labels": torch.stack(labels),
            "attention_mask": torch.stack(attn)}


class StepLogger(TrainerCallback):
    def __init__(self, log_path):
        self.log_path = log_path
        self.t0 = None

    def on_train_begin(self, args, state, control, **kw):
        self.t0 = time.time()

    def on_log(self, args, state, control, logs=None, **kw):
        if logs is None:
            return
        rec = {"step": state.global_step, "elapsed_s": round(time.time() - self.t0, 1),
               "loss": logs.get("loss"), "lr": logs.get("learning_rate"),
               "vram_alloc_gib": round(torch.cuda.memory_allocated() / 1024**3, 2),
               "vram_peak_gib": round(torch.cuda.max_memory_allocated() / 1024**3, 2)}
        if state.global_step > 0 and self.t0:
            rec["s_per_step"] = round(rec["elapsed_s"] / state.global_step, 1)
        with open(self.log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--max_steps", type=int, default=None, help="试训用；正式训练不传")
    ap.add_argument("--train_parquet", default=os.path.join(DATA_DIR, "train.parquet"))
    ap.add_argument("--out_dir", default=OUT_DIR)
    ap.add_argument("--matched_steps", type=int)
    args = ap.parse_args()
    if args.max_steps and args.matched_steps:
        ap.error("--max_steps and --matched_steps are mutually exclusive")

    os.makedirs(args.out_dir, exist_ok=True)
    train_ds = PackedDS(args.train_parquet)
    total_steps = (len(train_ds) + ACCUM - 1) // ACCUM
    print(f"packed seqs: {len(train_ds)} | accum {ACCUM} | total steps (trainer-reported): {total_steps}", flush=True)
    save_steps = max(1, (args.matched_steps or total_steps) // 4)  # 每 1/4 进度存一次 adapter

    from unsloth import FastLanguageModel
    model, tokenizer = FastLanguageModel.from_pretrained(
        model_name=BASE, max_seq_length=4096, dtype=torch.bfloat16,
        load_in_4bit=True, attn_implementation="sdpa")
    model = FastLanguageModel.get_peft_model(
        model, r=32, lora_alpha=32, lora_dropout=0.0, bias="none",
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj",
                        "gate_proj", "up_proj", "down_proj"],
        use_gradient_checkpointing="unsloth", random_state=42)
    model.print_trainable_parameters()

    targs = TrainingArguments(
        output_dir=args.out_dir,
        per_device_train_batch_size=1,
        gradient_accumulation_steps=ACCUM,
        num_train_epochs=1,
        max_steps=args.matched_steps or args.max_steps or -1,
        learning_rate=LR, lr_scheduler_type="cosine", warmup_ratio=0.03,
        bf16=True, optim="adamw_bnb_8bit",
        logging_steps=1, save_steps=save_steps,
        save_strategy="steps" if not args.max_steps else "no",
        save_only_model=not args.matched_steps, save_total_limit=2 if args.matched_steps else None, report_to=[], dataloader_num_workers=0,
        seed=42, max_grad_norm=1.0,
    )
    trainer = Trainer(model=model, args=targs, train_dataset=train_ds,
                      data_collator=collate,
                      callbacks=[StepLogger(os.path.join(args.out_dir, "train_metrics.jsonl"))])
    resume = None
    if args.matched_steps:
        from transformers.trainer_utils import get_last_checkpoint

        resume = get_last_checkpoint(args.out_dir)
    trainer.train(resume_from_checkpoint=resume)
    if not args.max_steps:
        trainer.save_model(os.path.join(args.out_dir, "final_adapter"))
        AutoTokenizer.from_pretrained(BASE).save_pretrained(os.path.join(args.out_dir, "final_adapter"))
    print("TRAIN DONE", flush=True)


if __name__ == "__main__":
    main()
