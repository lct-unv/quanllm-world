"""Matched structured-report evaluation on the archived rollout pools."""
import json
import math
import random
import statistics
import sys
import time
from concurrent.futures import ProcessPoolExecutor

from rollout_eval import GENERATORS, K, MODELS, OUT, problems, read, write


def jobs():
    pools = {g: read(f"generated_{g}") for g in GENERATORS}
    for q in problems():
        qid = q["question_id"]
        tests = json.loads(q["public_test_cases"])
        for g, pool in pools.items():
            for i, row in enumerate(pool[qid]):
                yield g, qid, i, q["question_content"], tests, row["code"]


def archived_jobs():
    for generator, qid, index, count in read("structured_candidate_order"):
        yield generator, qid, index, None, range(count), None


def public_case(job):
    from lcb_runner.evaluation.compute_code_generation_metrics import evaluate_generations_by_problem

    code, case = job
    sample = {"input_output": json.dumps({"inputs": [case["input"]],
                                         "outputs": [case["output"]], "fn_name": None})}
    result, _ = evaluate_generations_by_problem(([code], sample, False, 6))
    return result[0] == [True]


def public_truth():
    sys.path.insert(0, "/opt/eval/LiveCodeBench")
    rows = list(jobs())
    cases = list(dict.fromkeys((code, json.dumps(case, sort_keys=True))
                               for _, _, _, _, tests, code in rows for case in tests))
    with ProcessPoolExecutor(max_workers=8) as pool:
        outcomes = dict(zip(cases, pool.map(public_case,
            [(code, json.loads(case)) for code, case in cases]), strict=True))
    write("structured_public", [
        [outcomes[code, json.dumps(case, sort_keys=True)] for case in tests]
        for _, _, _, _, tests, code in rows
    ])


def schema(count):
    return {"type": "object", "additionalProperties": False,
            "required": ["public", "verdict"],
            "properties": {"public": {"type": "array", "minItems": count,
                "maxItems": count, "items": {"enum": ["pass", "fail"]}},
                "verdict": {"enum": ["pass", "fail"]}}}


def validate(text, count):
    try:
        report = json.loads(text)
    except ValueError:
        return None
    if (not isinstance(report, dict) or set(report) != {"public", "verdict"}
        or not isinstance(report["public"], list) or len(report["public"]) != count
        or any(x not in ("pass", "fail") for x in [*report["public"], report["verdict"]])):
        return None
    return report


def inference(model):
    from transformers import AutoTokenizer
    from vllm import LLM, SamplingParams
    from vllm.sampling_params import StructuredOutputsParams

    path = str(MODELS[model])
    tok = AutoTokenizer.from_pretrained(path)
    llm = LLM(model=path, quantization="fp8", max_model_len=8192,
              gpu_memory_utilization=.85, enforce_eager=True, max_num_seqs=32,
              max_num_batched_tokens=4096)
    rows = list(jobs())
    reports = []
    times = []
    for start in range(0, len(rows), 64):
        batch = rows[start:start+64]
        prompts, params = [], []
        for _, _, _, question, tests, code in batch:
            user = ("Evaluate the Python candidate against each public example in order. "
                    "Predict the suite verdict for the full problem, including unseen tests. "
                    "Return JSON with public (one pass/fail entry per example) and verdict (pass/fail)."
                    f"\n\nProblem:\n{question}\n\nPublic examples:\n"
                    + json.dumps(tests, ensure_ascii=False) + f"\n\nCandidate:\n{code}")
            prompt = tok.apply_chat_template([{"role": "user", "content": user}],
                tokenize=False, add_generation_prompt=True, enable_thinking=False)
            ids = tok.encode(prompt, add_special_tokens=False)
            if len(ids) > 7936:
                raise ValueError(f"Prompt exceeds context: {len(ids)} tokens")
            prompts.append({"prompt_token_ids": ids})
            params.append(SamplingParams(temperature=0, max_tokens=256,
                structured_outputs=StructuredOutputsParams(json=schema(len(tests)))))
        t = time.perf_counter()
        outputs = llm.generate(prompts, params, use_tqdm=False)
        times.append(time.perf_counter() - t)
        reports.extend(o.outputs[0].text for o in outputs)
        invalid = sum(validate(text, len(row[4])) is None
                      for text, row in zip(reports[-len(batch):], batch, strict=True))
        print(model, len(reports), "/", len(rows), "batch seconds", round(times[-1], 1),
              "invalid", invalid, flush=True)
        write(f"structured_{model}", {"seconds": sum(times), "reports": reports})


def expected_hit(buckets, budget):
    miss = 1.0
    for bucket in buckets:
        n = min(budget, len(bucket))
        if n:
            miss *= math.comb(len(bucket) - sum(bucket), n) / math.comb(len(bucket), n)
            budget -= n
    return 1 - miss


def summarize():
    rows = list(archived_jobs())
    public = read("structured_public")
    archive = {g: read(f"timed_truth_{g}")["truth"] for g in GENERATORS}
    out = {}
    for model in ("base14b", "surrogate"):
        raw = read(f"structured_{model}")
        assert len(raw["reports"]) == len(rows) == len(public)
        by_generator = {g: [] for g in GENERATORS}
        for (g, qid, idx, _, tests, _), text, gt in zip(rows, raw["reports"], public, strict=True):
            assert len(tests) == len(gt)
            r = validate(text, len(gt))
            suite = archive[g][qid][idx]
            real_public = ["pass" if x else "fail" for x in gt]
            correct = sum(x == y for x, y in zip(r["public"], real_public)) if r else 0
            by_generator[g].append((qid, suite, r, correct, len(gt)))
        for g, group in by_generator.items():
            valid = [x for x in group if x[2] is not None]
            pools = {}
            for qid, suite, report, _, _ in group:
                buckets = pools.setdefault(qid, [[], [], []])
                rank = 2 if report is None else int(report["verdict"] != "pass")
                buckets[rank].append(suite)
            assert all(sum(map(len, b)) == K for b in pools.values())
            out.setdefault(g, {})[model] = {
                "candidates": len(group), "coverage": len(valid) / len(group),
                "public_tests": sum(x[4] for x in group),
                "public_accuracy": sum(x[3] for x in group) / sum(x[4] for x in group),
                "suite_accuracy": sum((r["verdict"] == "pass") == suite
                                      for _, suite, r, _, _ in valid) / len(group),
                "curves": {b: statistics.mean(expected_hit(pool, b) for pool in pools.values())
                           for b in range(1, K+1)},
                "per_problem_b1": {qid: expected_hit(pool, 1) for qid, pool in pools.items()},
                "generation_seconds_all_pools": raw["seconds"],
            }
    rng = random.Random(71)
    for group in out.values():
        a = group["base14b"]["per_problem_b1"]
        b = group["surrogate"]["per_problem_b1"]
        delta = [b[i] - a[i] for i in a]
        boot = sorted(statistics.mean(rng.choices(delta, k=len(delta))) for _ in range(5000))
        group["b1_delta_ci"] = [boot[125], boot[4874]]
    write("structured_summary", out)
    print("STRUCTURED COMPLETE", flush=True)


if __name__ == "__main__":
    stage = sys.argv[1]
    if stage == "infer":
        inference(sys.argv[2])
    elif stage == "public":
        public_truth()
    elif stage == "summarize":
        summarize()
