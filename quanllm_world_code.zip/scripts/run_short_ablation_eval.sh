#!/bin/bash
set -euo pipefail
root=/mnt/e/quanllm-world
arm="$1"
exec bash /mnt/e/WSL/run_eval_gen.sh "$root/outputs/ablations_short/$arm/merged" "$root/outputs/ablations_short/$arm/dev.jsonl" dev 512
