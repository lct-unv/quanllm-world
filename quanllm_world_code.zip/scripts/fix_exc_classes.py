# 修正标注中的异常类别：pytest "E " 前缀行 / StopIteration / 无声终止（Killed）
# 直接对已产出的 transitions/rewards 做后处理，无需重跑沙箱。
import json
import re

EXC_ANY = re.compile(r"\b([A-Za-z_][\w.]*(?:Error|Exception|Interrupt|Exit|Warning|Iteration))\b")
E_ASSERT = re.compile(r"^E\s+assert", re.M)


def reclassify(case):
    if case.get("exc") not in ("Crash", "Failed"):
        return 0
    tb = case.get("traceback") or ""
    # pytest -x 格式：找 "E   XxxError: ..." / "E   assert ..." 行
    for line in reversed(tb.splitlines()):
        s = line.strip()
        if s.startswith("E "):
            s2 = s[1:].strip()
            m = EXC_ANY.search(s2)
            if m:
                case["exc"] = m.group(1).split(".")[-1]
                return 1
            if s2.startswith("assert"):
                case["exc"] = "AssertionError"
                return 1
    if not tb:
        case["exc"] = "Killed"   # 无声终止（内存顶格/进程被杀）
        return 1
    m = EXC_ANY.search(tb)
    if m:
        case["exc"] = m.group(1).split(".")[-1]
    elif any(l.strip().startswith("E ") for l in tb.splitlines()):
        case["exc"] = "AssertionError"  # pytest 断言差异体（头部被截断的）
    else:
        case["exc"] = "Failed"
    return 1


def main():
    from collections import Counter
    fixed = 0
    for path in (r"E:\quanllm-world\datasets\transitions.jsonl",
                 r"E:\quanllm-world\datasets\rewards.jsonl"):
        rows = []
        with open(path, encoding="utf-8") as f:
            for line in f:
                d = json.loads(line)
                cases = d["result"]["per_test"] if "result" in d else d["report"]["per_test"]
                for c in cases:
                    fixed += reclassify(c)
                rows.append(d)
        with open(path, "w", encoding="utf-8") as f:
            for d in rows:
                f.write(json.dumps(d, ensure_ascii=False) + "\n")
    print("fixed cases:", fixed)

    exc = Counter()
    with open(r"E:\quanllm-world\datasets\transitions.jsonl", encoding="utf-8") as f:
        for line in f:
            for c in json.loads(line)["result"]["per_test"]:
                if c["status"] == "fail":
                    exc[c["exc"]] += 1
    print("fail exc dist:", dict(exc.most_common(15)))


if __name__ == "__main__":
    main()
