"""Windows sandbox runner: job-object isolation for untrusted code execution.

Isolation mechanisms:
- Process tree kill: Job Object with KILL_ON_JOB_CLOSE; timeout -> TerminateJobObject
  (kills the whole tree), taskkill /T /F as fallback.
- Memory cap: Job Object JOB_OBJECT_LIMIT_JOB_MEMORY; allocation beyond the cap
  raises MemoryError inside the child.
- Network block (Python level): PYTHONPATH-injected sitecustomize replaces
  socket.socket / socket.create_connection so any outbound connection raises
  OSError immediately. NOTE: OS-level network isolation would need admin
  firewall rules; the Python-level block is the implemented mechanism.
"""
import ctypes
import os
import subprocess
import sys
import time
from ctypes import wintypes

kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
kernel32.CreateJobObjectW.restype = wintypes.HANDLE
kernel32.CreateJobObjectW.argtypes = [wintypes.LPVOID, wintypes.LPCWSTR]
kernel32.SetInformationJobObject.restype = wintypes.BOOL
kernel32.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, wintypes.LPVOID, wintypes.DWORD]
kernel32.AssignProcessToJobObject.restype = wintypes.BOOL
kernel32.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
kernel32.TerminateJobObject.restype = wintypes.BOOL
kernel32.TerminateJobObject.argtypes = [wintypes.HANDLE, wintypes.UINT]
kernel32.CloseHandle.restype = wintypes.BOOL
kernel32.CloseHandle.argtypes = [wintypes.HANDLE]

JOB_OBJECT_LIMIT_JOB_MEMORY = 0x00000200
JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
JobObjectExtendedLimitInformation = 9


class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("PerProcessUserTimeLimit", ctypes.c_int64),
        ("PerJobUserTimeLimit", ctypes.c_int64),
        ("LimitFlags", wintypes.DWORD),
        ("MinimumWorkingSetSize", ctypes.c_size_t),
        ("MaximumWorkingSetSize", ctypes.c_size_t),
        ("ActiveProcessLimit", wintypes.DWORD),
        ("Affinity", ctypes.c_size_t),
        ("PriorityClass", wintypes.DWORD),
        ("SchedulingClass", wintypes.DWORD),
    ]


class IO_COUNTERS(ctypes.Structure):
    _fields_ = [
        (n, ctypes.c_uint64)
        for n in (
            "ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
            "ReadTransferCount", "WriteTransferCount", "OtherTransferCount",
        )
    ]


class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION),
        ("IoInfo", IO_COUNTERS),
        ("ProcessMemoryLimit", ctypes.c_size_t),
        ("JobMemoryLimit", ctypes.c_size_t),
        ("PeakProcessMemoryLimit", ctypes.c_size_t),
        ("PeakJobMemoryLimit", ctypes.c_size_t),
    ]


def _make_job(job_mem_mb=None):
    job = kernel32.CreateJobObjectW(None, None)
    if not job:
        raise OSError(ctypes.get_last_error(), "CreateJobObject failed")
    info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
    flags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
    if job_mem_mb:
        flags |= JOB_OBJECT_LIMIT_JOB_MEMORY
        info.JobMemoryLimit = job_mem_mb * 1024 * 1024  # extended 结构顶层字段，不在 BasicLimitInformation 里
    info.BasicLimitInformation.LimitFlags = flags
    if not kernel32.SetInformationJobObject(
        job, JobObjectExtendedLimitInformation, ctypes.byref(info), ctypes.sizeof(info)
    ):
        raise OSError(ctypes.get_last_error(), "SetInformationJobObject failed")
    return job


def run_sandboxed(cmd, timeout_s=60, job_mem_mb=None, block_net=True, cwd=None, extra_env=None, stdin_data=None):
    """Run cmd in a job-object sandbox. Returns dict with rc/output/timed_out/elapsed."""
    job = _make_job(job_mem_mb)
    env = os.environ.copy()
    if block_net:
        netblock_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sandbox_netblock")
        env["PYTHONPATH"] = netblock_dir + os.pathsep + env.get("PYTHONPATH", "")
    if extra_env:
        env.update(extra_env)

    proc = subprocess.Popen(
        cmd, stdin=subprocess.PIPE if stdin_data is not None else subprocess.DEVNULL,
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        cwd=cwd, env=env, text=True, encoding="utf-8", errors="replace",
    )
    if not kernel32.AssignProcessToJobObject(job, int(proc._handle)):
        proc.kill()
        raise OSError(ctypes.get_last_error(), "AssignProcessToJobObject failed")

    t0 = time.time()
    timed_out = False
    try:
        out = proc.communicate(input=stdin_data, timeout=timeout_s)[0]
    except subprocess.TimeoutExpired:
        timed_out = True
        kernel32.TerminateJobObject(job, 1)  # kills entire tree
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(proc.pid)], capture_output=True)
        out = proc.communicate()[0]
    elapsed = time.time() - t0
    kernel32.CloseHandle(job)
    return {
        "rc": proc.returncode,
        "output": out or "",
        "timed_out": timed_out,
        "elapsed_s": round(elapsed, 1),
    }
