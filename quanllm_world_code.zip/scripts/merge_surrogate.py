# 4.4 训练后处理：合并最终 adapter 为 bf16 全量替身模型
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

BASE = r"E:\quanllm-coder\models\Qwen3-14B"
ADAPTER = r"E:\quanllm-world\outputs\surrogate_sft\final_adapter"
OUT = r"E:\quanllm-world\outputs\QuanLLM-World-Surrogate-14B"

def main():
    model = AutoModelForCausalLM.from_pretrained(BASE, dtype=torch.bfloat16, device_map="cpu")
    model = PeftModel.from_pretrained(model, ADAPTER)
    model = model.merge_and_unload()
    tok = AutoTokenizer.from_pretrained(BASE)
    model.save_pretrained(OUT)
    tok.save_pretrained(OUT)
    print("MERGED ->", OUT)

if __name__ == "__main__":
    main()
