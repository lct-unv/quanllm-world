#!/bin/bash
set -euo pipefail
cd /mnt/e/quanllm-world
export VLLM_USE_DEEP_GEMM=0 VLLM_USE_FLASHINFER_SAMPLER=0
v=/opt/vllm-env/bin/python
for model in base14b surrogate; do
  "$v" -u scripts/structured_rollout.py infer "$model"
done
