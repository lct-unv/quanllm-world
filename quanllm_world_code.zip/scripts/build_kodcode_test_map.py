# 用 KodCode-V1 的 pytest 单测回补 21K 池：按规范化题面对齐。
# 红线：subset == 'Leetcode' 整体排除（不进入回补表）。
import glob
import hashlib
import json
import re

import pyarrow.parquet as pq

V1 = sorted(glob.glob(r"E:\quanllm-world\datasets\KodCode-V1\data\train-*.parquet"))
POOL = r"E:\quanllm-coder\datasets\sft_mix_50k\train_16h.jsonl"
OUT_MAP = r"E:\quanllm-world\datasets\kodcode_tests.jsonl"

_ws = re.compile(r"\s+")


def qkey(text: str) -> str:
    return hashlib.sha1(_ws.sub(" ", text.strip().lower()).encode("utf-8")).hexdigest()


def main():
    n_rows = n_kept = 0
    with open(OUT_MAP, "w", encoding="utf-8") as out:
        for f in V1:
            t = pq.read_table(f, columns=["subset", "question_id", "question", "test"])
            for subset, q, qid, test in zip(
                t.column("subset").to_pylist(), t.column("question").to_pylist(),
                t.column("question_id").to_pylist(), t.column("test").to_pylist(),
            ):
                n_rows += 1
                if subset == "Leetcode" or not q or not test:
                    continue
                out.write(json.dumps({
                    "k": qkey(q), "qid": qid, "subset": subset, "test": test,
                }, ensure_ascii=False) + "\n")
                n_kept += 1
            print(f"{f.split(chr(92))[-1]} done, kept {n_kept}/{n_rows}", flush=True)
    print(f"map rows: {n_kept} (excluded Leetcode & empty) of {n_rows}")

    test_map = {}
    with open(OUT_MAP, encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            test_map.setdefault(d["k"], d)
    print(f"unique question keys: {len(test_map)}")

    n_hit = n_leet = 0
    with open(POOL, encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            k = qkey(d["messages"][0]["content"])
            if k in test_map:
                n_hit += 1
    print(f"pool samples with pytest backfill: {n_hit} / 21000")


if __name__ == "__main__":
    main()
