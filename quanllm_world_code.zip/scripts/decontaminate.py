# 3.5 去污染：对全部变异体样本（原代码+变异代码+单测文本）跑 9-gram 去污染。
# 对照集（清单固定，不得更改）：
#   - LiveCodeBench：datasets/_decontamination/livecodebench/*.jsonl + eval/lcb_v6_full.jsonl
#   - BigCodeBench：datasets/_decontamination/bigcodebench/*.parquet + eval/bcb_instruct{,_hard}.jsonl
# 命中（任一 9-gram 交集非空）即整条丢弃。复用 V2.3 open-r1 风格：小写去标点按词切分，9-gram 哈希。
import glob
import json
import re
import sys

import pyarrow.parquet as pq

sys.path.insert(0, r"E:\quanllm-coder\scripts")
sys.path.insert(0, r"E:\quanllm-world\scripts")

N_GRAM = 9
_ws = re.compile(r"[^a-z0-9]+")


def norm_words(text):
    return [w for w in _ws.split(text.lower()) if w]


def ngrams(text, n=N_GRAM):
    words = norm_words(text)
    return {hash(" ".join(words[i:i + n])) for i in range(len(words) - n + 1)}


def build_eval_ngrams():
    grams = set()
    # LiveCodeBench（V2.3 去污染目录）
    seen_qid = set()
    for f in sorted(glob.glob(r"E:\quanllm-coder\datasets\_decontamination\livecodebench\*.jsonl")):
        n0 = 0
        with open(f, encoding="utf-8") as fh:
            for line in fh:
                try:
                    d = json.loads(line)
                except json.JSONDecodeError:
                    continue
                qid, q = d.get("question_id"), d.get("question_content")
                if not q or qid in seen_qid:
                    continue
                seen_qid.add(qid)
                grams |= ngrams(q)
                n0 += 1
        print(f"LCB(decon) {f.split(chr(92))[-1]}: +{n0}", flush=True)
    # LiveCodeBench v6 full（三层基准层 1）
    n0 = 0
    with open(r"E:\quanllm-coder\eval\lcb_v6_full.jsonl", encoding="utf-8") as fh:
        for line in fh:
            try:
                d = json.loads(line)
            except json.JSONDecodeError:
                continue
            qid, q = d.get("question_id"), d.get("question_content")
            if not q or qid in seen_qid:
                continue
            seen_qid.add(qid)
            grams |= ngrams(q)
            n0 += 1
    print(f"LCB(eval v6 full): +{n0}", flush=True)
    # BigCodeBench（V2.3 去污染目录全部 parquet 版本）
    for f in sorted(glob.glob(r"E:\quanllm-coder\datasets\_decontamination\bigcodebench\**\*.parquet", recursive=True)):
        t = pq.read_table(f)
        for col in ("instruct_prompt", "complete_prompt"):
            if col in t.column_names:
                for q in t.column(col).to_pylist():
                    if q:
                        grams |= ngrams(q)
    print("BCB(decon parquets) merged", flush=True)
    # BigCodeBench eval 三层基准层 2/3
    for f in (r"E:\quanllm-coder\eval\bcb_instruct.jsonl", r"E:\quanllm-coder\eval\bcb_instruct_hard.jsonl"):
        n0 = 0
        with open(f, encoding="utf-8") as fh:
            for line in fh:
                d = json.loads(line)
                q = d.get("instruct_prompt")
                if q:
                    grams |= ngrams(q)
                    n0 += 1
        print(f"BCB(eval) {f.split(chr(92))[-1]}: +{n0}", flush=True)
    print(f"eval 9-gram set size: {len(grams)}", flush=True)
    return grams


def main():
    grams = build_eval_ngrams()

    # 样本侧文本：原代码 + 变异代码 + 单测文本（题面已在 V2.3 上游去污染）
    payloads = {}
    import sys as _s
    _s.path.insert(0, r"E:\quanllm-world\scripts")
    from filter_pool import extract_code, qkey
    from extract_tests import extract_tests

    test_map = {}
    with open(r"E:\quanllm-world\datasets\kodcode_tests.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            test_map[d["k"]] = d["test"]

    with open(r"E:\quanllm-world\datasets\source_pool_filtered.jsonl", encoding="utf-8") as f:
        for i, line in enumerate(f):
            d = json.loads(line)
            code = extract_code(d["messages"][-1]["content"]) or ""
            tc = test_map.get(qkey(d["messages"][0]["content"]))
            if tc:
                ttext = tc
            else:
                ttext = "\n".join(i2 + "\n" + o for i2, o in extract_tests(d["messages"][0]["content"]))
            payloads[i] = code + "\n" + ttext

    kept, dropped = [], []
    with open(r"E:\quanllm-world\datasets\mutants.jsonl", encoding="utf-8") as f:
        for mid, line in enumerate(f):
            d = json.loads(line)
            base = payloads.get(d["src_idx"])
            if base is None:
                dropped.append((mid, "no_payload"))
                continue
            text = base + "\n" + d["code"]
            if not ngrams(text).isdisjoint(grams):
                dropped.append((mid, "contaminated"))
            else:
                kept.append(mid)

    dropped_ids = {m for m, _ in dropped}
    from collections import Counter
    with open(r"E:\quanllm-world\datasets\mutants_clean.jsonl", "w", encoding="utf-8") as out:
        with open(r"E:\quanllm-world\datasets\mutants.jsonl", encoding="utf-8") as f:
            for mid, line in enumerate(f):
                if mid not in dropped_ids:
                    d = json.loads(line)
                    d["mid"] = mid
                    out.write(json.dumps(d, ensure_ascii=False) + "\n")
    stats = {
        "in": mid + 1, "kept": len(kept),
        "dropped": len(dropped), "drop_reasons": dict(Counter(r for _, r in dropped)),
        "eval_grams": len(grams), "n_gram": N_GRAM,
        "control_sets": ["livecodebench_decon_jsonl", "lcb_v6_full", "bigcodebench_decon_parquets",
                         "bcb_instruct", "bcb_instruct_hard"],
    }
    with open(r"E:\quanllm-world\datasets\decontam.stats.json", "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=1)
    print(json.dumps(stats, ensure_ascii=False, indent=1), flush=True)


if __name__ == "__main__":
    main()
