# 阶段 3 指标分析：替身 vs 底座零样本，全部对照沙箱真实标注
import json
import math
import re
import sys
from pathlib import Path
from collections import Counter, defaultdict

import pyarrow.parquet as pq

DATA = Path(__file__).resolve().parents[1] / "datasets"

CASE_LINE = re.compile(r"[-*]\s*([\w<>\[\]_\.]+)\s*[:：]\s*(pass|fail|通过|不通过|passed|failed)\s*(?:[（(]([^)）]+)[)）])?", re.I)
CONCL = re.compile(r"结论[:：]\s*(通过|不通过)")


def load_gt():
    dev = pq.read_table(DATA / "packed/dev.parquet", columns=["mids"])
    dev_mids = set()
    for mids in dev.column("mids").to_pylist():
        dev_mids.update(mids)
    gt_t, gt_r = {}, {}
    with open(DATA / "transitions.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            if d["id"] in dev_mids:
                gt_t[d["id"]] = d
    with open(DATA / "rewards.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            if d["id"] in dev_mids:
                gt_r[d["id"]] = d
    return gt_t, gt_r


def load_preds(path):
    out = defaultdict(dict)
    with open(path, encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            out[d["id"]][d["task"]] = d
    return out


def parse_transition(text):
    cases = {}
    for m in CASE_LINE.finditer(text):
        name = m.group(1)
        st = m.group(2).lower()
        status = "pass" if st in ("pass", "通过", "passed") else "fail"
        exc = m.group(3).strip() if m.group(3) else None
        cases[name] = (status, exc)
    c = CONCL.search(text)
    verdict = None
    if c:
        verdict = "pass" if c.group(1) == "通过" else "fail"
    return cases, verdict


def parse_reward(text):
    m = re.search(r"\{[^{}]*\"verdict\"[^{}]*\}", text, re.S)
    if not m:
        m2 = re.search(r"verdict[\"'\s:]+\"?(pass|fail)\"?", text, re.I)
        return (m2.group(1).lower() if m2 else None)
    try:
        d = json.loads(m.group(0))
        v = d.get("verdict")
        return v.lower() if isinstance(v, str) else None
    except Exception:
        m2 = re.search(r"\"verdict\"\s*:\s*\"(pass|fail)\"", m.group(0))
        return m2.group(1) if m2 else None


def macro_transition_acc(preds, gt_t):
    per_sample, unparsed = [], 0
    for mid, gt in gt_t.items():
        p = preds.get(mid, {}).get("transition")
        if not p:
            continue
        cases, _ = parse_transition(p["text"])
        actual = {c["name"]: c["status"] for c in gt["result"]["per_test"]}
        if not cases or not actual:
            unparsed += 1
            continue
        hits = sum(1 for n, st in actual.items() if cases.get(n, (None,))[0] == st)
        per_sample.append(hits / len(actual))
    return (sum(per_sample) / len(per_sample) if per_sample else 0.0), len(per_sample), unparsed


def failure_f1(preds, gt_t):
    """逐用例多分类：pass / WrongAnswer / AssertionError / NameError / Timeout / Crash类 / 其他。宏 F1。"""
    def norm_exc(e):
        if not e:
            return "Other"
        e = e.strip()
        for k in ("AssertionError", "NameError", "WrongAnswer", "Timeout", "ValueError",
                  "IndexError", "TypeError", "UnboundLocalError", "MemoryError", "KeyError"):
            if k.lower() in e.lower():
                return k
        return "Other"

    y_true, y_pred = [], []
    for mid, gt in gt_t.items():
        p = preds.get(mid, {}).get("transition")
        if not p:
            continue
        cases, _ = parse_transition(p["text"])
        for c in gt["result"]["per_test"]:
            t = "pass" if c["status"] == "pass" else norm_exc(c["exc"])
            pr = cases.get(c["name"])
            if pr is None or pr[0] == "pass":
                y_pred.append("pass")
            else:
                y_pred.append(norm_exc(pr[1]) if pr[1] else "Other")
            y_true.append(t)
    labels = sorted(set(y_true) | set(y_pred))
    f1s = []
    for lb in labels:
        tp = sum(1 for a, b in zip(y_true, y_pred) if a == lb and b == lb)
        fp = sum(1 for a, b in zip(y_true, y_pred) if a != lb and b == lb)
        fn = sum(1 for a, b in zip(y_true, y_pred) if a == lb and b != lb)
        if tp + fp + fn == 0:
            continue
        prec = tp / (tp + fp) if tp + fp else 0
        rec = tp / (tp + fn) if tp + fn else 0
        f1s.append(2 * prec * rec / (prec + rec) if prec + rec else 0)
    return sum(f1s) / len(f1s) if f1s else 0.0


def reward_prf(preds, gt_r):
    """fail 为正类。"""
    tp = fp = fn = tn = unparsed = 0
    for mid, gt in gt_r.items():
        p = preds.get(mid, {}).get("reward")
        if not p:
            continue
        pv = parse_reward(p["text"])
        if pv not in ("pass", "fail"):
            unparsed += 1
            continue
        av = gt["verdict"]
        if pv == "fail" and av == "fail":
            tp += 1
        elif pv == "fail" and av == "pass":
            fp += 1
        elif pv == "pass" and av == "fail":
            fn += 1
        else:
            tn += 1
    acc = (tp + tn) / max(1, tp + tn + fp + fn)
    prec = tp / (tp + fp) if tp + fp else 0
    rec = tp / (tp + fn) if tp + fn else 0
    f1 = 2 * prec * rec / (prec + rec) if prec + rec else 0
    return {"acc": round(acc, 4), "precision": round(prec, 4), "recall": round(rec, 4),
            "f1": round(f1, 4), "unparsed": unparsed,
            "confusion": {"tp": tp, "fp": fp, "fn": fn, "tn": tn}}


def ece(preds, gt_map, task, nbins=10):
    """verdict 二值校准。置信度=判定 token 概率。"""
    pairs = []
    for mid, gt in gt_map.items():
        p = preds.get(mid, {}).get(task)
        if not p or p.get("verdict_conf") is None:
            continue
        if task == "reward":
            pv = parse_reward(p["text"])
            av = gt["verdict"]
        else:
            _, pv = parse_transition(p["text"])
            av = "pass" if gt["result"]["verdict"] == "pass" else "fail"
        if pv not in ("pass", "fail"):
            continue
        conf = min(max(p["verdict_conf"], 0.5), 1.0)
        pairs.append((conf, 1.0 if pv == av else 0.0))
    if not pairs:
        return None
    bins = defaultdict(list)
    for conf, hit in pairs:
        b = min(int((conf - 0.5) * nbins * 2), nbins * 2 - 1)  # [0.5,1] 10 桶
        bins[b].append((conf, hit))
    e = 0.0
    table = []
    for b in sorted(bins):
        items = bins[b]
        mc = sum(x[0] for x in items) / len(items)
        ma = sum(x[1] for x in items) / len(items)
        e += len(items) / len(pairs) * abs(ma - mc)
        table.append({"range": f"{0.5 + b * 0.05:.2f}-{0.55 + b * 0.05:.2f}",
                      "n": len(items), "mean_conf": round(mc, 4), "emp_acc": round(ma, 4)})
    return {"ece": round(e, 4), "n": len(pairs), "bins": table}


def main():
    gt_t, gt_r = load_gt()
    out = {}
    for name, path in (("surrogate", DATA / "eval_pred_surrogate.jsonl"),
                       ("baseline", DATA / "eval_pred_baseline.jsonl")):
        try:
            preds = load_preds(path)
        except FileNotFoundError:
            continue
        acc, n_acc, unp = macro_transition_acc(preds, gt_t)
        out[name] = {
            "transition_macro_acc": round(acc, 4),
            "transition_samples_scored": n_acc,
            "transition_unparsed": unp,
            "transition_failure_macro_f1": round(failure_f1(preds, gt_t), 4),
            "reward": reward_prf(preds, gt_r),
            "ece_reward": ece(preds, gt_r, "reward"),
            "ece_transition": ece(preds, gt_t, "transition"),
        }
    print(json.dumps(out, ensure_ascii=False, indent=1))
    with open(DATA / "stage3_metrics.json", "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
