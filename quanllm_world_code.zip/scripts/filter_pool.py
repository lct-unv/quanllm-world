# 源池前置过滤管线：21K -> 执行验证池
# 规则（用户指定）：单测全部通过 + 单样本运行时长 <5s + 无网络/文件系统副作用
# 测试来源：KodCode 题 -> KodCode-V1 pytest 单测（Leetcode 子集已整体排除）；
#           其余 -> 题面示例 I/O（extract_tests）
import json
import os
import re
import sys
import tempfile
import time
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from extract_tests import extract_tests, qkey

PY = sys.executable
TEST_TIMEOUT_S = 5.0     # 单条测试硬超时
SAMPLE_BUDGET_S = 5.0    # 单样本运行时长预算（用户规则）
JOB_MEM_MB = 1024
TEST_MAP = r"E:\quanllm-world\datasets\kodcode_tests.jsonl"

# 静态副作用扫描：命中即拒（网络在沙箱内也被封，这里做显式标注）
SIDE_EFFECT_PAT = re.compile(
    r"(import\s+(socket|requests|urllib|http|ftplib|telnetlib)|"
    r"from\s+(socket|requests|urllib|http)\b|"
    r"\bos\.(system|popen|remove|unlink|rmdir|makedirs|mkdir|rename|replace)\b|"
    r"\bsubprocess\b|\bshutil\.|"
    r"\bopen\s*\([^)]*['\"][wax][b+]?['\"]|"
    r"\.write_text\s*\(|\.write_bytes\s*\(|"
    r"\bctypes\b|\beval\s*\(|\bexec\s*\()"
)

CODE_BLOCK = re.compile(r"```python[^\n]*\n(.*?)```", re.S)


def extract_code(assistant: str):
    blocks = CODE_BLOCK.findall(assistant)
    if not blocks:
        return None
    return blocks[-1].strip() + "\n"


def norm_tokens(s: str):
    return s.replace("\r\n", "\n").split()


def _as_float(tok: str):
    try:
        return float(tok)
    except ValueError:
        return None


def output_matches(got: str, expected: str) -> bool:
    """token 级比对；双 token 均为数值时按 1e-4 相对/绝对容差（容忍浮点打印精度差异）。"""
    import math
    gt, et = norm_tokens(got), norm_tokens(expected)
    if len(gt) != len(et):
        return False
    for g, e in zip(gt, et):
        if g == e:
            continue
        gf, ef = _as_float(g), _as_float(e)
        if gf is None or ef is None or not math.isclose(gf, ef, rel_tol=1e-4, abs_tol=1e-6):
            return False
    return True


def _fs_clean(td, allow=()):
    return [x for x in os.listdir(td) if x not in allow]


def run_io_sample(args):
    idx, code, tests = args
    from sandbox import run_sandboxed
    total_rt = 0.0
    with tempfile.TemporaryDirectory(prefix=f"sbx{idx}_") as td:
        sol = os.path.join(td, "sol.py")
        with open(sol, "w", encoding="utf-8") as f:
            f.write(code)
        for ti, (stdin_data, expected) in enumerate(tests):
            r = run_sandboxed(
                [PY, sol], timeout_s=TEST_TIMEOUT_S, job_mem_mb=JOB_MEM_MB,
                block_net=True, cwd=td, extra_env={"PYTHONIOENCODING": "utf-8"},
                stdin_data=stdin_data,
            )
            total_rt += r["elapsed_s"]
            if r["timed_out"]:
                return False, {"i": idx, "reason": f"timeout_test{ti}", "rt": total_rt}
            if r["rc"] != 0:
                return False, {"i": idx, "reason": f"crash_test{ti}", "rt": total_rt}
            if not output_matches(r["output"], expected):
                return False, {"i": idx, "reason": f"wrong_answer_test{ti}", "rt": total_rt}
            if _fs_clean(td, allow={"sol.py"}):
                return False, {"i": idx, "reason": f"fs_side_effect_test{ti}", "rt": total_rt}
    return True, {"i": idx, "reason": "ok", "rt": total_rt}


IMPORT_PAT = re.compile(r"^\s*from\s+solution\s+import\s+(.+)$", re.M)
DEF_PAT = re.compile(r"^def\s+(\w+)\s*\(", re.M)


def run_pytest_sample(args):
    idx, code, test_code, io_fallback = args
    from sandbox import run_sandboxed

    def _attempt(code_text):
        with tempfile.TemporaryDirectory(prefix=f"sbx{idx}_") as td:
            with open(os.path.join(td, "solution.py"), "w", encoding="utf-8") as f:
                f.write(code_text)
            with open(os.path.join(td, "test_main.py"), "w", encoding="utf-8") as f:
                f.write(test_code)
            r = run_sandboxed(
                [PY, "-m", "pytest", "test_main.py", "-q", "--tb=no", "-p", "no:cacheprovider"],
                timeout_s=TEST_TIMEOUT_S, job_mem_mb=JOB_MEM_MB, block_net=True, cwd=td,
                extra_env={"PYTHONIOENCODING": "utf-8"},
            )
            extra = _fs_clean(td, allow={"solution.py", "test_main.py", "__pycache__"})
            return r, extra

    r, extra = _attempt(code)
    salvaged = False
    if r["rc"] == 2 and not r["timed_out"]:
        # 收集错误多为"测试导入的函数名 ≠ 解答定义的函数名"；单函数解答补别名重试
        imported = set()
        for m in IMPORT_PAT.finditer(test_code):
            imported.update(x.strip().split(" as ")[0] for x in m.group(1).split(","))
        defined = DEF_PAT.findall(code)
        missing = imported - set(defined)
        if missing and len(defined) == 1:
            alias = code + "\n" + "\n".join(f"{m} = {defined[0]}" for m in missing) + "\n"
            r2, extra2 = _attempt(alias)
            if r2["rc"] == 0:
                r, extra, salvaged = r2, extra2, True

    if r["timed_out"]:
        return False, {"i": idx, "reason": "timeout_pytest", "rt": r["elapsed_s"]}
    if r["rc"] == 5 or "no tests ran" in (r["output"] or ""):
        # 该测试文件不是 pytest 形态，回退到示例 I/O 路径
        if io_fallback:
            ok, info = run_io_sample((idx, code, io_fallback))
            info["reason"] = info["reason"] if not ok else "ok_io_fallback"
            return ok, info
        return False, {"i": idx, "reason": "pytest_no_tests", "rt": r["elapsed_s"]}
    if extra:
        return False, {"i": idx, "reason": "fs_side_effect_pytest", "rt": r["elapsed_s"]}
    if r["rc"] != 0:
        return False, {"i": idx, "reason": "pytest_fail", "rt": r["elapsed_s"]}
    return True, {"i": idx, "reason": "ok_alias" if salvaged else "ok", "rt": r["elapsed_s"]}


def run_job(args):
    idx, mode, code, payload = args
    if mode == "pytest":
        return run_pytest_sample((idx, code, payload[0], payload[1]))
    return run_io_sample((idx, code, payload))


def filter_pool(pool_path, out_path, stats_path, limit=None, workers=12):
    test_map = {}
    with open(TEST_MAP, encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            test_map[d["k"]] = d["test"]
    print(f"pytest test map: {len(test_map)} keys", flush=True)

    jobs = []
    n_no_code = n_static = n_no_tests = n_pytest = 0
    with open(pool_path, encoding="utf-8") as f:
        for i, line in enumerate(f):
            if limit and i >= limit:
                break
            d = json.loads(line)
            code = extract_code(d["messages"][-1]["content"])
            if not code:
                n_no_code += 1
                continue
            if SIDE_EFFECT_PAT.search(code):
                n_static += 1
                continue
            tc = test_map.get(qkey(d["messages"][0]["content"]))
            if tc:
                jobs.append((i, "pytest", code, (tc, extract_tests(d["messages"][0]["content"]))))
                n_pytest += 1
                continue
            tests = extract_tests(d["messages"][0]["content"])
            if not tests:
                n_no_tests += 1
                continue
            jobs.append((i, "io", code, tests))
    print(f"jobs: {len(jobs)} (pytest={n_pytest}, io={len(jobs)-n_pytest}) | "
          f"no_code: {n_no_code} | static_reject: {n_static} | no_tests: {n_no_tests}", flush=True)

    kept, drops = [], {}
    t0 = time.time()
    with Pool(workers) as pool:
        for done, (ok, info) in enumerate(pool.imap_unordered(run_job, jobs, chunksize=4)):
            reason = info["reason"]
            if ok and info["rt"] < SAMPLE_BUDGET_S:
                kept.append(info["i"])
            else:
                key = "over_5s_total" if ok else re.sub(r"_test\d+$", "", reason)
                drops[key] = drops.get(key, 0) + 1
            if done % 1000 == 0:
                print(f"  {done}/{len(jobs)} kept={len(kept)} elapsed={time.time()-t0:.0f}s", flush=True)

    kept_set = set(kept)
    n_in = 0
    with open(pool_path, encoding="utf-8") as f, open(out_path, "w", encoding="utf-8") as out:
        for i, line in enumerate(f):
            if limit and i >= limit:
                break
            n_in = i + 1
            if i in kept_set:
                out.write(line)
    stats = {
        "input_rows": n_in, "jobs": len(jobs), "jobs_pytest": n_pytest, "jobs_io": len(jobs) - n_pytest,
        "no_code": n_no_code, "static_reject": n_static, "no_tests": n_no_tests,
        "kept": len(kept), "drop_reasons": drops,
        "wall_time_s": round(time.time() - t0, 1),
    }
    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=1)
    print(json.dumps(stats, ensure_ascii=False, indent=1), flush=True)


if __name__ == "__main__":
    limit = int(sys.argv[1]) if len(sys.argv) > 1 else None
    filter_pool(
        r"E:\quanllm-coder\datasets\sft_mix_50k\train_16h.jsonl",
        r"E:\quanllm-world\datasets\source_pool_filtered.jsonl",
        r"E:\quanllm-world\datasets\source_pool_filtered.stats.json",
        limit=limit,
    )
