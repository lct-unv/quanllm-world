"""Summarize the matched 20-step controls and update the draft."""
import json
import re
import sys
from pathlib import Path

from stage3_analysis import load_gt, load_preds, macro_transition_acc
from audit_dev_reports import reward_verdict

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs/ablations_short"
ARMS = {"joint": "Joint with rationale", "reward": "Reward only",
        "no_rationale": "Joint without rationale"}


def main():
    gt_t, gt_r = load_gt()
    results = {}
    matched = None
    for arm in ARMS:
        preds = load_preds(OUT / arm / "dev.jsonl")
        assert len(preds) == 256 and all(set(tasks) == {"transition", "reward"}
                                         for tasks in preds.values())
        ids = set(preds)
        if matched is None:
            matched = ids
        assert matched == ids and ids <= gt_t.keys() and ids <= gt_r.keys()
        total = len(ids)
        acc, scored, _ = macro_transition_acc(preds, {mid: gt_t[mid] for mid in ids})
        verdicts = {mid: reward_verdict(p["reward"]["text"]) for mid, p in preds.items()}
        results[arm] = {
            "transition": acc * scored / total,
            "reward": sum(v == gt_r[mid]["verdict"] for mid, v in verdicts.items()) / total,
            "coverage": sum(v in ("pass", "fail") for v in verdicts.values()) / total,
        }
    summary = {"steps": 20, "candidates": sorted(matched), "results": results}

    sys.path.insert(0, str(ROOT / "paper/figs"))
    from fig3456_data import BLUE, GRAY, plt, save, style

    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.6), sharey=True, layout="constrained")
    for ax, metric, title in zip(axes, ("transition", "reward"),
                                ("(a) Per-test accuracy", "(b) Suite-verdict accuracy")):
        style(ax)
        for row, arm in enumerate(ARMS):
            if metric == "transition" and arm == "reward":
                continue
            value = 100 * results[arm][metric]
            ax.scatter(value, row, color=BLUE if arm == "joint" else GRAY)
            ax.annotate(f"{value:.1f}%", (value, row), xytext=(5, 0),
                        textcoords="offset points", va="center")
        ax.set(xlim=(0, 113), ylim=(2.5, -.5), title=title, xlabel="Accuracy (%)",
               xticks=[0, 25, 50, 75, 100])
    axes[0].set_yticks(range(len(ARMS)), list(ARMS.values()))
    save(fig, "fig8_ablations")

    temp = OUT / "summary.tmp"
    temp.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    temp.replace(OUT / "summary.json")


if __name__ == "__main__":
    main()
