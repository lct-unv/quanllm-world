# 沙箱标注：每个变异体重跑原始单测，产出 Transition 与 Reward 两类样本。
# 纪律：单样本墙钟 10s、内存上限 1024MB（Job Object）、禁网、失败样本同样保留。
# 逐用例结果：I/O 路逐对执行；pytest 路 JUnit XML 解析。
import difflib
import ast
import json
import os
import re
import sys
import tempfile
import time
import xml.etree.ElementTree as ET
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sandbox import run_sandboxed
from filter_pool import extract_code, output_matches, PY, qkey
from extract_tests import extract_tests

POOL = r"E:\quanllm-world\datasets\source_pool_filtered.jsonl"
TEST_MAP = r"E:\quanllm-world\datasets\kodcode_tests.jsonl"
MUTANTS = r"E:\quanllm-world\datasets\mutants.jsonl"
OUT_T = r"E:\quanllm-world\datasets\transitions.jsonl"
OUT_R = r"E:\quanllm-world\datasets\rewards.jsonl"
STATS = r"E:\quanllm-world\datasets\annotate.stats.json"

SAMPLE_TIMEOUT_S = 10.0   # 单样本（变异体）墙钟预算
JOB_MEM_MB = 1024

EXC_PAT = re.compile(r"^([A-Za-z_][\w.]*(?:Error|Exception|Interrupt|Exit|Warning))\b")


def _tb_summary(text, limit=400):
    lines = [l for l in (text or "").strip().splitlines() if l.strip()]
    tail = lines[-3:] if lines else []
    s = "\n".join(tail)
    return s[-limit:]


def _exc_class(text):
    for line in reversed((text or "").strip().splitlines()):
        m = EXC_PAT.match(line.strip())
        if m:
            return m.group(1).split(".")[-1]
    return "Crash"


def run_io_cases(code, tests, idx):
    """逐用例执行，返回 (cases, verdict)。单样本总预算 10s。"""
    cases = []
    t_start = time.time()
    with tempfile.TemporaryDirectory(prefix=f"ann{idx}_") as td:
        sol = os.path.join(td, "sol.py")
        with open(sol, "w", encoding="utf-8") as f:
            f.write(code)
        for ti, (stdin_data, expected) in enumerate(tests):
            remain = SAMPLE_TIMEOUT_S - (time.time() - t_start)
            if remain <= 0.05:
                cases.append({"name": f"io_{ti}", "status": "fail", "exc": "Timeout",
                              "traceback": "sample wall-clock budget exhausted"})
                continue
            r = run_sandboxed([PY, sol], timeout_s=remain, job_mem_mb=JOB_MEM_MB,
                              block_net=True, cwd=td, extra_env={"PYTHONIOENCODING": "utf-8"},
                              stdin_data=stdin_data)
            if r["timed_out"]:
                cases.append({"name": f"io_{ti}", "status": "fail", "exc": "Timeout",
                              "traceback": f"exceeded {remain:.1f}s"})
            elif r["rc"] != 0:
                cases.append({"name": f"io_{ti}", "status": "fail",
                              "exc": _exc_class(r["output"]),
                              "traceback": _tb_summary(r["output"])})
            elif not output_matches(r["output"], expected):
                cases.append({"name": f"io_{ti}", "status": "fail", "exc": "WrongAnswer",
                              "traceback": f"got: {r['output'][:120]!r} expected: {expected[:120]!r}"})
            else:
                cases.append({"name": f"io_{ti}", "status": "pass", "exc": None, "traceback": None})
    verdict = "pass" if all(c["status"] == "pass" for c in cases) and cases else "fail"
    return cases, verdict


IMPORT_PAT = re.compile(r"^\s*from\s+solution\s+import\s+(.+)$", re.M)
DEF_PAT = re.compile(r"^def\s+(\w+)\s*\(", re.M)


def run_pytest_cases(code, test_code, idx):
    """pytest 一次运行 + JUnit XML 逐用例解析；收集错误时按别名规则重试一次。"""
    def _attempt(text):
        with tempfile.TemporaryDirectory(prefix=f"ann{idx}_") as td:
            open(os.path.join(td, "solution.py"), "w", encoding="utf-8").write(text)
            open(os.path.join(td, "test_main.py"), "w", encoding="utf-8").write(test_code)
            xml_path = os.path.join(td, "r.xml")
            r = run_sandboxed(
                [PY, "-m", "pytest", "test_main.py", "-v", "--tb=short",
                 f"--junitxml={xml_path}", "-p", "no:cacheprovider"],
                timeout_s=SAMPLE_TIMEOUT_S, job_mem_mb=JOB_MEM_MB, block_net=True, cwd=td,
                extra_env={"PYTHONIOENCODING": "utf-8"})
            xml_text = None
            if os.path.exists(xml_path):
                with open(xml_path, encoding="utf-8", errors="replace") as f:
                    xml_text = f.read()
            return r, xml_text

    r, xml_text = _attempt(code)
    if r["rc"] == 2 and not r["timed_out"]:
        imported = set()
        for m in IMPORT_PAT.finditer(test_code):
            imported.update(x.strip().split(" as ")[0] for x in m.group(1).split(","))
        defined = DEF_PAT.findall(code)
        missing = imported - set(defined)
        if missing and len(defined) == 1:
            alias = code + "\n" + "\n".join(f"{m} = {defined[0]}" for m in missing) + "\n"
            r2, xml2 = _attempt(alias)
            if r2["rc"] != 2:
                r, xml_text = r2, xml2

    if r["timed_out"]:
        return ([{"name": "<whole_run>", "status": "fail", "exc": "Timeout",
                  "traceback": f"exceeded {SAMPLE_TIMEOUT_S:.0f}s"}], "fail")

    cases = []
    if xml_text:
        try:
            root = ET.fromstring(xml_text)
            for tc in root.iter("testcase"):
                name = tc.get("name", "?")
                node = tc.find("failure")
                kind = "failure"
                if node is None:
                    node = tc.find("error")
                    kind = "error"
                if node is None:
                    cases.append({"name": name, "status": "pass", "exc": None, "traceback": None})
                else:
                    text = node.text or ""
                    cases.append({"name": name, "status": "fail",
                                  "exc": _exc_class(text) if text else ("CollectionError" if kind == "error" else "AssertionError"),
                                  "traceback": _tb_summary(text)})
        except ET.ParseError:
            cases.append({"name": "<parse>", "status": "fail", "exc": "CollectionError",
                          "traceback": _tb_summary(r["output"])})
    if not cases:
        cases.append({"name": "<whole_run>", "status": "fail", "exc": _exc_class(r["output"]),
                      "traceback": _tb_summary(r["output"])})
    verdict = "pass" if all(c["status"] == "pass" for c in cases) else "fail"
    return cases, verdict


def work(args):
    mid, src_idx, mode, orig_code, mut_code, op, gen_label, payload = args
    if mode == "pytest":
        cases, verdict = run_pytest_cases(mut_code, payload, mid)
        tests_repr = {"format": "pytest", "code": payload}
    else:
        cases, verdict = run_io_cases(mut_code, payload, mid)
        tests_repr = {"format": "stdio", "cases": [{"input": i, "expected": o} for i, o in payload]}

    # diff 基线用 unparse 归一化后的原代码，消除格式噪声，让 diff 只呈现变异本身
    diff = "\n".join(difflib.unified_diff(
        ast.unparse(ast.parse(orig_code)).splitlines(), mut_code.splitlines(),
        fromfile="original", tofile="mutant", lineterm=""))
    n_pass = sum(1 for c in cases if c["status"] == "pass")
    report = {"total": len(cases), "passed": n_pass, "failed": len(cases) - n_pass,
              "per_test": cases}

    transition = {
        "id": mid, "src_idx": src_idx, "op": op,
        "original_code": orig_code, "diff": diff, "tests": tests_repr,
        "result": {"per_test": cases, "verdict": verdict},
    }
    reward = {
        "id": mid, "src_idx": src_idx, "op": op,
        "mutated_code": mut_code, "tests": tests_repr,
        "report": report, "verdict": verdict,
    }
    return transition, reward, verdict, gen_label


def main(limit=None, workers=16):
    test_map = {}
    with open(TEST_MAP, encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            test_map[d["k"]] = d["test"]

    payloads = {}   # src_idx -> (mode, payload, orig_code)
    with open(POOL, encoding="utf-8") as f:
        for i, line in enumerate(f):
            d = json.loads(line)
            code = extract_code(d["messages"][-1]["content"])
            tc = test_map.get(qkey(d["messages"][0]["content"]))
            if tc:
                payloads[i] = ("pytest", tc, code)
            else:
                tests = extract_tests(d["messages"][0]["content"])
                if tests and code:
                    payloads[i] = ("io", tests, code)

    jobs = []
    with open(MUTANTS, encoding="utf-8") as f:
        for mid, line in enumerate(f):
            if limit and mid >= limit:
                break
            d = json.loads(line)
            p = payloads.get(d["src_idx"])
            if not p:
                continue
            mode, payload, orig = p
            jobs.append((mid, d["src_idx"], mode, orig, d["code"],
                         d["op"], d["actual_pass"], payload))
    print(f"mutants to annotate: {len(jobs)}", flush=True)

    flips = 0
    verdicts = {"pass": 0, "fail": 0}
    t0 = time.time()
    with open(OUT_T, "w", encoding="utf-8") as ft, open(OUT_R, "w", encoding="utf-8") as fr, \
            Pool(workers) as pool:
        for done, (tr, rw, verdict, gen_label) in enumerate(
                pool.imap_unordered(work, jobs, chunksize=4)):
            ft.write(json.dumps(tr, ensure_ascii=False) + "\n")
            fr.write(json.dumps(rw, ensure_ascii=False) + "\n")
            verdicts[verdict] += 1
            if (verdict == "pass") != bool(gen_label):
                flips += 1
            if done % 2000 == 0:
                print(f"  {done}/{len(jobs)} flips={flips} elapsed={time.time()-t0:.0f}s", flush=True)
    stats = {"mutants": len(jobs), "verdicts": verdicts,
             "label_flips_vs_generation": flips, "wall_time_s": round(time.time() - t0, 1)}
    with open(STATS, "w", encoding="utf-8") as f:
        json.dump(stats, f, ensure_ascii=False, indent=1)
    print(json.dumps(stats, ensure_ascii=False, indent=1), flush=True)


if __name__ == "__main__":
    main(limit=int(sys.argv[1]) if len(sys.argv) > 1 else None)
