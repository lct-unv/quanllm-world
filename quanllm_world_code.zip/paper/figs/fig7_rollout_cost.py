"""Plot held-out rollout quality against execution budget and measured work."""
import json

from fig3456_data import BLUE, GRAY, GRID, ROOT, plt, save, style

summary_path = ROOT / "outputs/rollout_eval/summary.json"
methods = [
    ("surrogate", "Surrogate", BLUE, "-", "D"),
    ("base_judge", "Base-model judge", "#865020", "--", "s"),
    ("generator", "Generator likelihood", GRAY, "-.", "^"),
    ("random", "Uniform selection", "#222222", ":", "o"),
]


def main():
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    labels = {"coder7b": "Qwen2.5-Coder-7B-Instruct", "base14b": "Qwen3-14B"}
    fig, axes = plt.subplots(2, 2, figsize=(7.3, 5.5), sharey='row', layout="constrained")
    for row, (generator, study) in enumerate(summary.items()):
        curves = study["curves"]
        budget = sorted(map(int, curves))
        for key, name, color, linestyle, marker in methods:
            rate = [100 * curves[str(b)][key] for b in budget]
            ranking = study["ranking_seconds"].get(key, 0) / study["problems"]
            seconds = [ranking + curves[str(b)][f"{key}_execution_seconds"] for b in budget]
            for ax, x in zip(axes[row], (budget, seconds)):
                ax.plot(x, rate, label=name, color=color, ls=linestyle, marker=marker,
                        lw=1.15, ms=3.8, markerfacecolor="white")
        for ax in axes[row]:
            style(ax)
            ax.set_ylim((25, 42) if row == 0 else (37, 53))
            ax.grid(axis="y", color=GRID, lw=.45)
        axes[row, 0].set(title=f"{labels[generator]} candidates",
                         xlabel="Execution budget per problem", ylabel="Verified solve rate (%)",
                         xticks=budget)
        axes[row, 1].set(xlabel="Ranking time + evaluator worker time (s/problem)")
    handles, names = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, names, loc="outside upper center", ncol=4, frameon=False)
    save(fig, "fig7_rollout_cost")


if __name__ == "__main__":
    main()
