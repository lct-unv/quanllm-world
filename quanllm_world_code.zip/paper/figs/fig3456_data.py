"""Render Figures 3–6 from the archived evaluation and training records."""
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "datasets"
OUT = ROOT / "paper" / "figures"
INK = "#161616"
BLUE = "#1E557E"
GRAY = "#595959"
GRID = "#D5D5D5"
PALE = "#DBDBDB"


plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "axes.linewidth": .7,
    "axes.titlesize": 11,
    "axes.labelsize": 10,
    "xtick.major.width": .7,
    "ytick.major.width": .7,
    "pdf.use14corefonts": False,
    "font.size": 10,
    "text.color": INK,
    "axes.labelcolor": INK,
    "axes.titlecolor": INK,
    "axes.labelpad": 8,
    "xtick.color": GRAY,
    "ytick.color": GRAY,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "pdf.fonttype": 42,
})


def style(ax):
    ax.set_axisbelow(True)
    ax.spines[["top", "right"]].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(INK)
    ax.tick_params(length=3, color=INK, direction="out")


def save(fig, name):
    OUT.mkdir(parents=True, exist_ok=True)
    for extension in ("png", "pdf"):
        fig.savefig(OUT / f"{name}.{extension}", dpi=600, facecolor="white",
                    bbox_inches="tight", pad_inches=.08)
    plt.close(fig)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def paired_utility():
    """Replay held-out ranking and analytically average uniform random selection."""
    import pyarrow.parquet as pq

    sys.path.insert(0, str(ROOT / "scripts"))
    from stage3_analysis import load_preds, parse_reward

    packed = pq.read_table(DATA / "packed" / "test.parquet", columns=["mids"])
    mids = {mid for sequence in packed["mids"].to_pylist() for mid in sequence}
    predictions = load_preds(DATA / "eval_pred_surrogate_test.jsonl")
    groups = defaultdict(list)
    with (DATA / "rewards.jsonl").open(encoding="utf-8") as source:
        for line in source:
            row = json.loads(line)
            mid = row["id"]
            prediction = predictions.get(mid, {}).get("reward")
            if mid not in mids or prediction is None:
                continue
            verdict = parse_reward(prediction["text"])
            confidence = prediction.get("verdict_conf")
            score = .5
            if confidence is not None and verdict in ("pass", "fail"):
                score = confidence if verdict == "pass" else 1 - confidence
            groups[row["src_idx"]].append((score, row["verdict"] == "pass"))

    rng = np.random.default_rng(0)
    for budget in (1, 2):
        pairs = []
        for candidates in groups.values():
            count = len(candidates)
            if count < budget:
                continue
            failed = sum(not passes for _, passes in candidates)
            random_hit = 1 - math.comb(failed, budget) / math.comb(count, budget)
            ranked = sorted(candidates, key=lambda item: -item[0])
            guided_hit = any(passes for _, passes in ranked[:budget])
            pairs.append((random_hit, guided_hit))
        scores = np.array(pairs)
        improvement = scores[:, 1] - scores[:, 0]
        sample = rng.integers(len(scores), size=(10000, len(scores)))
        lo, hi = np.quantile(improvement[sample].mean(axis=1), [.025, .975])
        yield len(scores), 100 * scores.mean(axis=0), (100 * lo, 100 * hi)


def utility():
    archived = read_json(DATA / "utility_test.json")
    fig, ax = plt.subplots(figsize=(6.8, 2.65), layout="constrained")
    style(ax)
    labels = []
    for y, (count, (random, guided), (lo, hi)) in enumerate(paired_utility()):
        labels.append(f"B = {y + 1}  (n = {count})")
        ax.hlines(y, random, guided, color=PALE, lw=1.15, zorder=1)
        ax.scatter(random, y, marker="o", facecolor="white", edgecolor=GRAY, s=36, zorder=3)
        ax.scatter(guided, y, marker="D", color=BLUE, s=37, zorder=3)
        for value, offset, color, align in (
            (random, -8, GRAY, "right"), (guided, 8, BLUE, "left")
        ):
            ax.annotate(f"{value:.1f}%", (value, y), xytext=(offset, 0),
                        textcoords="offset points", ha=align, va="center",
                        color=color, fontweight="bold")
        ax.text((random + guided) / 2, y - .15,
                f"+{guided - random:.1f} pp  [{lo:.1f}, {hi:.1f}]",
                ha="center", va="bottom", color=BLUE, fontsize=9)
    ax.scatter([], [], marker="o", facecolor="white", edgecolor=GRAY, s=36, label="Random selection")
    ax.scatter([], [], marker="D", color=BLUE, s=37, label="Surrogate-guided")
    ax.legend(loc="lower left", bbox_to_anchor=(-.02, 1.01), ncol=2, frameon=False)
    ax.set(xlim=(0, 114), ylim=(1.45, -.47), xticks=[0, 25, 50, 75, 100],
           xlabel="Verified-correct hit rate (%)")
    ax.xaxis.set_major_formatter(PercentFormatter(100, decimals=0, symbol=""))
    ax.set_yticks([0, 1], labels)
    ax.tick_params(axis="y", length=0)
    ax.spines["left"].set_visible(False)
    ax.grid(axis="x", color=GRID, lw=.45)
    ax.text(.99, 1.06, f"Candidate ranking AUC  {archived['filtering']['auc']:.3f}",
            transform=ax.transAxes, ha="right", color=BLUE, fontweight="bold")
    save(fig, "fig3_utility")


def calibration():
    data = read_json(DATA / "stage3_metrics.json")["surrogate"]
    fig, ax = plt.subplots(figsize=(5.9, 2.15), layout="constrained")
    style(ax)
    for y, task in enumerate(("reward", "transition")):
        metric = data[f"ece_{task}"]
        point, = metric["bins"]
        accuracy = 100 * point["emp_acc"]
        confidence = 100 * point["mean_conf"]
        ax.hlines(y, accuracy, confidence, color=GRAY, lw=1, ls="--")
        ax.scatter(confidence, y, marker="s", facecolor="white", edgecolor=GRAY, s=33, zorder=3,
                   label="Mean confidence" if y == 0 else None)
        ax.scatter(accuracy, y, color=BLUE, s=34, zorder=3,
                   label="Empirical accuracy" if y == 0 else None)
        ax.annotate(f"{accuracy:.2f}%", (accuracy, y), xytext=(-7, 0),
                    textcoords="offset points", ha="right", va="center", color=BLUE)
        ax.text(100.17, y, f"ECE {metric['ece']:.3f}", va="center", color=INK, fontsize=9)
    ax.set(xlim=(97.15, 101), ylim=(1.55, -.55),
           xticks=[98, 99, 100], xlabel="Verdict confidence or accuracy (%)")
    ax.set_yticks([0, 1], ["Reward verdict", "Transition verdict"])
    ax.xaxis.set_major_formatter(PercentFormatter(100, decimals=0, symbol=""))
    ax.legend(loc="lower left", bbox_to_anchor=(-.01, 1), ncol=2, frameon=False, fontsize=9)
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0)
    ax.set_title("Verdict confidence in the 95–100% bin", loc="left", pad=22)
    save(fig, "fig4_calibration")


def operators():
    sys.path.insert(0, str(ROOT / "scripts"))
    from stage3_analysis import load_gt, load_preds, parse_transition

    ground_truth, _ = load_gt()
    predictions = load_preds(DATA / "eval_pred_surrogate.jsonl")
    by_operator = defaultdict(list)
    for mid, row in ground_truth.items():
        prediction = predictions.get(mid, {}).get("transition")
        if prediction is None:
            continue
        cases, _ = parse_transition(prediction["text"])
        actual = row["result"]["per_test"]
        if cases and actual:
            hits = sum(cases.get(test["name"], (None,))[0] == test["status"] for test in actual)
            by_operator[row["op"]].append(hits / len(actual))

    names = {"rename": "Rename", "delete": "Delete", "swap": "Swap",
             "const": "Constant", "binop": "Binary operator", "boundary": "Boundary"}
    keys = sorted(names, key=lambda key: -np.mean(by_operator[key]))
    keys.remove("boundary")
    keys.append("boundary")
    fig, (ax, support) = plt.subplots(1, 2, figsize=(6.6, 2.7), sharey=True,
                                     width_ratios=[2.4, 1], layout="constrained")
    for axis in (ax, support):
        style(axis)
        axis.spines["left"].set_visible(False)
        axis.tick_params(axis="y", length=0)
    for y, key in enumerate(keys):
        values = by_operator[key]
        mean = 100 * np.mean(values)
        color = GRAY if key == "boundary" else BLUE
        ax.scatter(mean, y, color=color, s=38, zorder=3)
        ax.annotate(f"{mean:.1f}%", (mean, y), xytext=(6, 0),
                    textcoords="offset points", va="center", color=color, fontsize=9)
        support.barh(y, len(values), color=PALE, edgecolor=GRAY, linewidth=.65, height=.48)
        support.annotate(str(len(values)), (len(values), y), xytext=(5, 0),
                         textcoords="offset points", va="center", fontsize=9)
    ax.set(xlim=(75, 101), xticks=[75, 80, 85, 90, 95, 100], xlabel="Macro accuracy (%)")
    ax.xaxis.set_major_formatter(PercentFormatter(100, decimals=0, symbol=""))
    ax.set_title("(a) Prediction by operator", loc="left")
    support.set_title("(b) Sample count", loc="left")
    ax.grid(axis="x", color=GRID, lw=.45)
    ax.set_yticks(range(len(keys)), [names[key] for key in keys])
    ax.invert_yaxis()
    support.set(xlim=(0, 760), xticks=[0, 250, 500], xlabel="Scored mutants")
    save(fig, "fig5_operators")


def training():
    log = ROOT / "outputs" / "surrogate_sft" / "train_metrics.jsonl"
    records = [json.loads(line) for line in log.read_text(encoding="utf-8").splitlines()]
    records = [row for row in records if row["loss"] is not None]
    steps = np.array([row["step"] for row in records])
    losses = np.array([row["loss"] for row in records])
    hours = records[-1]["elapsed_s"] / 3600
    window = 8
    average = np.convolve(losses, np.ones(window) / window, mode="valid")

    fig, ax = plt.subplots(figsize=(6.3, 2.65), layout="constrained")
    style(ax)
    ax.plot(steps, losses, color=GRAY, lw=.65, alpha=.75, label="Logged loss")
    ax.plot(steps[window - 1:], average, color=BLUE, lw=1.45,
            label="8-step trailing mean")
    for index, offset, align in ((0, 8, "left"), (-1, -8, "right")):
        ax.scatter(steps[index], losses[index], color=BLUE, s=33, zorder=3)
        ax.annotate(f"{losses[index]:.4f}", (steps[index], losses[index]),
                    xytext=(offset, 8), textcoords="offset points", ha=align,
                    color=BLUE, fontweight="bold")
    ax.set(xlim=(0, 202), ylim=(0, .62), xticks=[0, 50, 100, 150, 197],
           xlabel="Optimizer step", ylabel="Training loss")
    ax.grid(axis="y", color=GRID, lw=.45)
    ax.legend(loc="upper right", frameon=False, fontsize=9)
    ax.set_title(f"One 24 GB GPU · {hours:.1f} h", loc="left", pad=8)
    save(fig, "fig6_training")


if __name__ == "__main__":
    utility()
    calibration()
    operators()
    training()

