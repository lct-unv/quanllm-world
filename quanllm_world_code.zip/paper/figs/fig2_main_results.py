"""Render the archived dev-set structured output audit."""
import json
from fig3456_data import BLUE, GRAY, GRID, INK, ROOT, plt, save, style

audit = json.loads((ROOT / "data/dev_audit.json").read_text(encoding="utf-8"))
total = audit["total"]
models = ["Surrogate", "Qwen3-14B", "Qwen2.5-Coder-7B"]
keys = ("surrogate", "baseline", "coder7b")
panels = [
    ("(a) All test IDs present", "transition_full_coverage"),
    ("(b) Structured report with suite verdict", "reward_complete_reports"),
]
fig, axes = plt.subplots(1, 2, figsize=(7.25, 2.4), sharey=True, layout="constrained")
for ax, (title, field) in zip(axes, panels):
    style(ax)
    ax.set_title(title, loc="left")
    for row, key in enumerate(keys):
        count = audit[key][field]
        ax.barh(row, 100 * count / total, height=.4,
                color=BLUE if row == 0 else GRAY)
        ax.text(100 * count / total + 2, row, f"{count:,}", va="center", fontsize=9)
    ax.set(xlim=(0, 121), ylim=(2.6, -.6), xticks=[0, 25, 50, 75, 100],
           xlabel="Share of dev candidates (%)")
    ax.spines["left"].set_visible(False)
    ax.grid(axis="x", color=GRID, lw=.45)
axes[0].set_yticks(range(3), models)
fig.suptitle(f"Structured outputs on {total:,} candidates per model")
save(fig, "fig2_main_results")
