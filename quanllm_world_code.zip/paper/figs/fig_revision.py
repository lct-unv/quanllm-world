"""Render the paired effects, budget curves, and qualitative trace."""
import json
import sys
from collections import defaultdict

import numpy as np
from fig3456_data import BLUE, GRAY, INK, ROOT, plt, save, style

sys.path.insert(0, str(ROOT / "scripts"))
from structured_rollout import archived_jobs, read, validate

GENERATORS = {"coder7b": "Qwen2.5-Coder-7B", "base14b": "Qwen3-14B"}


def paired():
    outcomes = read("structured_public")
    base = read("structured_base14b")["reports"]
    surrogate = read("structured_surrogate")["reports"]
    truth = {g: read(f"timed_truth_{g}")["truth"] for g in GENERATORS}
    grouped = defaultdict(lambda: defaultdict(list))
    for (g, q, i, _, tests, _), observed, a, b in zip(archived_jobs(), outcomes, base, surrogate, strict=True):
        target = ["pass" if v else "fail" for v in observed]
        reports = [validate(x, len(tests)) for x in (a, b)]
        counts = [sum(v == t for v, t in zip(r["public"], target, strict=True)) if r else 0
                  for r in reports]
        correct = [int(bool(r) and (r["verdict"] == "pass") == truth[g][q][i]) for r in reports]
        grouped[g][q].append((counts[1]-counts[0], len(target), correct[1]-correct[0]))
    summary = read("structured_summary")
    rng = np.random.default_rng(71)
    estimates = {}
    for g, groups in grouped.items():
        x = np.array([np.sum(v, axis=0) for v in groups.values()])
        boot = x[rng.integers(len(x), size=(10000,len(x)))].sum(axis=1)
        total = x.sum(axis=0)
        vals = [100*total[0]/total[1], 100*total[2]/(8*len(x))]
        intervals = [np.quantile(100*boot[:,0]/boot[:,1],[.025,.975]),
                     np.quantile(100*boot[:,2]/(8*len(x)),[.025,.975])]
        r = summary[g]
        vals.append(100*(r["surrogate"]["curves"]["1"]-r["base14b"]["curves"]["1"]))
        intervals.append(100*np.array(r["b1_delta_ci"]))
        estimates[g] = [(float(v), [float(y) for y in bounds]) for v,bounds in zip(vals,intervals)]
    return estimates


def effects():
    result = paired()
    fig, axes = plt.subplots(1,2,figsize=(7.3,2.8),width_ratios=[1.55,1],layout="constrained")
    for ax, title, fields, names, limits in [
        (axes[0], "(a) Prediction accuracy", (0,1), ("Public tests","Full suite"), (-3,14)),
        (axes[1], "(b) Verified solves at B = 1", (2,), ("One execution",), (-2,5)),
    ]:
        style(ax)
        ax.axvline(0,color=GRAY,lw=.7,ls="--")
        for row,(field,label) in enumerate(zip(fields,names)):
            for i,(g, name) in enumerate(GENERATORS.items()):
                v,(lo,hi)=result[g][field]
                color,marker=(BLUE,"D") if i==0 else ("#88572B","o")
                y=row+(i-.5)*.26
                ax.hlines(y,lo,hi,color=color,lw=1.2)
                ax.scatter(v,y,color=color,marker=marker,s=27,label=name if row==0 else None)
        ax.set(title=title,xlabel="Surrogate minus base (pp)",xlim=limits,
               ylim=(len(fields)-.58,-.42))
        ax.set_yticks(range(len(fields)),names)
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc="outside upper center",ncol=2,frameon=False)
    save(fig,"fig9_structured_rollouts")


def budgets():
    data=read("summary")
    fig,axes=plt.subplots(1,2,figsize=(7.3,3.05),sharey=True,layout="constrained")
    methods=[("surrogate","Surrogate",BLUE,"-","D"),
             ("base_judge","Base judge","#88572B","--","s"),
             ("generator","Generator likelihood",GRAY,"-.","^"),
             ("random","Uniform",INK,":","o")]
    for ax,(g,name) in zip(axes,GENERATORS.items()):
        style(ax)
        curves=data[g]["curves"]
        for k,label,color,ls,marker in methods:
            ax.plot(range(1,9),[100*curves[str(b)][k] for b in range(1,9)],label=label,
                    color=color,ls=ls,marker=marker,ms=3.5,lw=1.1)
        ceiling=100*curves["8"]["random"]
        ax.axhline(ceiling,ls=(0,(5,3)),lw=.8,color="#777777",label="Exhaustive ceiling")
        ax.text(1.12,ceiling+.65,f"{ceiling:.1f}%",color=GRAY,fontsize=9)
        ax.set(title=name+" candidates",xlabel="Execution budget per problem",
               xticks=[1,2,4,6,8],ylim=(25,54))
        ax.grid(axis="y",alpha=.22)
    axes[0].set_ylabel("Verified solve rate (%)")
    handles,labels=axes[0].get_legend_handles_labels()
    fig.legend(handles,labels,loc="outside upper center",ncol=3,frameon=False,fontsize=9)
    save(fig,"fig4_rollout_budget")


def trace():
    data=[["Test","Input","Sandbox","Transition","Reward"],
          ["io_0","1 1","WrongAnswer","WrongAnswer","Pass"],
          ["io_1","3 7","Pass","Pass","Pass"],
          ["io_2","13 10","Pass","Pass","WrongAnswer"],
          ["Suite","All","Fail","Fail","Fail"]]
    fig,ax=plt.subplots(figsize=(7.3,2.0))
    ax.axis("off")
    t=ax.table(cellText=data,cellLoc="center",bbox=[0,.04,1,.78],
               colWidths=[.12,.13,.25,.25,.25])
    t.auto_set_font_size(False)
    t.set_fontsize(10)
    for (y,x),cell in t.get_celld().items():
        cell.set_edgecolor("white")
        cell.get_text().set_fontfamily("monospace")
        cell.set_facecolor("#E8EFF5" if y in (0,4) else "#F3F5F7")
        if x==4 and y in (1,3):
            cell.set_facecolor("#F5E3D5")
    ax.text(.02,.91,"Candidate 15375  |  a > b  to  a >= b", transform=ax.transAxes,
            fontfamily="monospace",fontsize=10)
    save(fig,"fig_s3_execution_trace")


if __name__=="__main__":
    effects()
    budgets()
    trace()
