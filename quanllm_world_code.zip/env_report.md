# V2.3 环境版本清单

盘点日期：2026-11-12 ｜ 机器：Windows 11 + RTX 5090 D v2（24GB，sm_120）

## Python 解释器

| 项 | 值 |
|---|---|
| 路径 | `C:\Program Files\Python313\python.exe` |
| 版本 | Python 3.13.3（MSC v.1943 64 bit） |
| GPU | NVIDIA GeForce RTX 5090 D v2，CUDA 13.0（驱动 610.88） |

## 关键包版本

| 包 | 版本 |
|---|---|
| unsloth | 2026.11.1 |
| unsloth_zoo | 2026.11.1 |
| torch | 2.11.0+cu130 |
| transformers | 4.57.6 |
| peft | 0.21.2 |
| trl | 1.15.0 |
| datasets | 4.8.5 |
| bitsandbytes | 0.50.2 |

相关配套：accelerate 1.15.0、triton-windows 3.8.0.post29、cut-cross-entropy 25.1.1、huggingface_hub 0.36.2、tokenizers 0.22.2、modelscope 1.40.2、xformers 0.0.35（与 torch 2.11 不匹配，未使用，注意力走 SDPA）

## 完整版本清单（pip freeze）

```
accelerate==1.15.0
acres==0.5.0
aiofiles==25.1.0
aiohappyeyeballs==2.6.2
aiohttp==3.14.0
aiosignal==1.4.0
altair==6.2.1
annotated-doc==0.0.4
annotated-types==0.7.0
anyio==4.13.0
appdirs==1.4.4
attrs==26.1.0
autograd==1.8.0
autoray==0.8.4
bitsandbytes==0.50.2
bleach==6.4.0
blinker==1.9.0
cachetools==7.1.4
certifi==2026.10.23
cffi==2.1.1
charset-normalizer==3.4.7
ci-info==0.4.0
click==8.4.1
colorama==0.4.6
configobj==5.0.9
configparser==7.2.0
contourpy==1.3.3
cramjam==2.11.0
cryptography==50.0.2
cut-cross-entropy==25.1.1
cycler==0.12.1
datasets==4.8.5
diastatic-malt==2.15.3
diffusers==0.39.0
dill==0.4.1
distro==1.9.0
docstring_parser==0.18.0
docx==0.2.4
einops==0.8.2
etelemetry==0.3.1
fastjsonschema==2.22.2
fastparquet==2026.5.0
filelock==3.29.4
fitz==0.0.1.dev2
flag_gems==5.0.2
fonttools==4.63.0
frontend==0.0.3
frozenlist==1.8.0
fsspec==2026.2.0
gast==0.7.0
gitdb==4.0.12
GitPython==3.1.50
greenlet==3.5.6
h11==0.16.0
hf-xet==1.5.1
hf_transfer==0.1.9
httpcore==1.0.9
httplib2==0.31.2
httptools==0.8.0
httpx==0.28.1
huggingface_hub==0.36.2
idna==3.18
importlib_metadata==10.1.0
iniconfig==2.3.1
itsdangerous==2.2.0
Jinja2==3.1.6
jiter==0.15.0
joblib==1.5.3
json5==0.17.3
jsonschema-specifications==2025.9.1
jsonschema==4.26.0
jupyter_core==5.9.1
jupytext==1.19.6
kaggle==2.2.5
kagglesdk==0.1.38
kiwisolver==1.5.0
looseversion==1.3.0
lxml==6.1.1
markdown-it-py==4.2.0
MarkupSafe==3.0.3
matplotlib==3.10.9
mdit-py-plugins==0.6.1
mdurl==0.1.2
modelscope-hub==0.6.1
modelscope==1.40.2
mpmath==1.3.0
msgspec==0.22.0
multidict==6.7.1
multiprocess==0.70.19
narwhals==2.22.1
nbformat==5.11.1
nest-asyncio==1.6.0
networkx==3.6.1
nibabel==5.4.2
nipype==1.11.0
nltk==3.9.4
numpy==2.4.6
openai==2.41.1
packaging==26.0
pandas==3.0.3
pathlib==1.0.1
peft==0.21.2
pennylane==0.45.0
pennylane_lightning==0.45.0
pillow==12.1.1
pip==26.1.1
platformdirs==4.13.5
pluggy==1.7.0
propcache==0.5.2
protobuf==7.35.1
prov==2.1.1
psutil==7.2.2
puremagic==2.2.0
pyarrow==24.0.0
pycparser==3.12
pydantic==2.13.4
pydantic_core==2.46.4
pydeck==0.9.2
pydot==4.0.1
Pygments==2.20.0
PyMuPDF==1.27.2.3
pyparsing==3.3.2
pypdf==6.14.2
pypinyin==0.55.0
pyxnat==1.6.4
PyYAML==6.0.3
qutip==5.3.0
rdflib==7.6.0
referencing==0.37.0
regex==2026.5.9
requests==2.34.2
rich==15.0.0
rpds-py==2026.5.1
rustworkx==0.17.1
safetensors==0.8.0
scikit-learn==1.8.0
scipy-openblas32==0.3.33.0.0
scipy==1.17.1
sentencepiece==0.2.2
setuptools==70.2.0
shellingham==1.5.4
simplejson==4.1.1
six==1.17.0
smmap==5.0.3
sniffio==1.3.1
SQLAlchemy==2.0.48
starlette==1.3.1
streamlit==1.58.0
structlog==26.1.0
sympy==1.14.0
tenacity==9.1.4
termcolor==3.3.0
text-unidecode==1.3
threadpoolctl==3.6.0
tokenizers==0.22.2
toml==0.10.2
tomlkit==0.15.0
torch-geometric==2.8.0
torch==2.11.0+cu130
torchao==0.18.0
torchvision==0.26.0+cu130
tqdm==4.68.2
traitlets==5.16.1
traits==7.1.0
transformers==4.57.6
triton-windows==3.8.0.post29
trl==1.15.0
typeguard==4.6.0
typer==0.25.1
typing-inspection==0.4.2
typing_extensions==4.15.0
tyro==1.0.17
tzdata==2026.2
ucimlrepo==0.0.7
unsloth==2026.11.1
unsloth_zoo==2026.11.1
urllib3==2.7.0
uvicorn==0.49.0
watchdog==6.0.0
webencodings==0.6.1
websockets==16.0
wheel==0.48.0
xformers==0.0.35
xxhash==3.7.0
yarl==1.24.2
zipp==4.1.2
```

## 附：WSL2 推理环境（阶段二用，独立于上表）

| 项 | 值 |
|---|---|
| 发行版 | Ubuntu 24.04.3（WSL2，rootfs 导入自清华 TUNA ubuntu-base） |
| Python | 3.12（venv：`/opt/vllm-env`） |
| vllm | 0.33.0 |
| torch | 2.14.0+cu130 |
| flashinfer-python | 0.7.2.post1 |

## D0 决策记录（2026-11-12）

- **判定**：V2.3 为全局 Python 3.13.3 + 用户级 site-packages（非 conda/venv），无法干净复制 → 新建独立 venv `E:\quanllm-world\.venv`（同为 Python 3.13.3），按 `requirements-v23.txt`（192 项 freeze）逐版本对齐
- **bitsandbytes**：遵守"不得更换构建"约束——V2.3 实测可用的即 PyPI 官方 `bitsandbytes-0.50.2-py3-none-win_amd64.whl`（内置 cuda118–cuda132 全套 DLL），新环境钉同版本 = 同一构建
- **torch**：`2.11.0+cu130` 经 `--extra-index-url https://download.pytorch.org/whl/cu130` 获取，其余包走清华 TUNA
- **偏离项**（两处，均不影响训练栈）：`fitz==0.0.1.dev2` 镜像无源，剔除（PyMuPDF==1.27.2.3 提供同一 import）；`flag_gems==5.0.2` 与 `numpy==2.4.6` 存在声明冲突（V2.3 本身即带病共存），以 `--no-deps` 补装同版本
- **对齐结果**：torch 2.11.0+cu130 / torchvision 0.26.0+cu130 / bitsandbytes 0.50.2 / unsloth 2026.11.1 / trl 1.15.0 / transformers 4.57.6 / peft 0.21.2 / datasets 4.8.5 / accelerate 1.15.0 / triton-windows 3.8.0.post29 / numpy 2.4.6 等全部与 V2.3 一致；venv 体积 4.7GB

## 验收门结果（2026-11-12）

| 项 | 结果 |
|---|---|
| env_report.md 完整 | ✅（本文件） |
| 冒烟（新 venv，4-bit 加载 Qwen3-14B + 前向） | ✅ SMOKE PASS：无内核错误；静态权重 9.29 GiB（与 V2.3 一致）；前向峰值 **10.55 GiB**，为训练态锚点 16.4GB 的 0.64 倍，符合"前向显著更低"预期；脚本 `scripts/smoke_4bit_forward.py` |
| 沙箱样例 | ✅ SANDBOX VERIFY PASS：Job Object 整树杀（超时 10.1s 准点终止）、内存上限 1GiB（越界抛 MemoryError）、Python 层禁网（socket 封堵）、JUnit XML 逐用例结果+traceback；脚本 `scripts/verify_sandbox.py` |
