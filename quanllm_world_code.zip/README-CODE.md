# Execution-Verified Mutation Surrogates — research code

Extract both archives into the same folder and run commands from the extraction root. Install the CPU analysis dependencies with `python -m pip install numpy matplotlib pyarrow`.

```sh
python scripts/stage3_analysis.py
python scripts/audit_dev_reports.py
python scripts/rollout_eval.py summarize
python scripts/structured_rollout.py summarize
python scripts/report_short_ablations.py
python paper/figs/fig3456_data.py
python paper/figs/fig2_main_results.py
python paper/figs/fig7_rollout_cost.py
python paper/figs/fig_revision.py
```

The analysis commands write metric summaries under `data/`, `datasets/` or `outputs/`, and figure scripts write to `paper/figures/`. Use a working extraction to preserve the original archived files. The short-ablation reporting script generates Supplementary Fig. S2. The opening schematic is part of the manuscript package.

Scripts for data construction, full training and fresh inference record the original Windows/WSL pipeline. These stages require local path configuration, original model checkpoints and upstream inputs: Qwen3-14B and Qwen2.5-Coder-7B-Instruct, the teacher checkpoint, source-pool and benchmark snapshots, and the original LiveCodeBench runner/prompt helper. `env_report.md` and `requirements-v23.txt` document the run environment. The public archived-results workflow above uses the supplied labels and predictions and runs on CPU.
